# Conformance campaign

wardowl 2.1.0 at commit `5d0f414a346511ad48a6c1c8b411259e6d908b84`, workflow run 40313285885, Python 3.12.15: 3 targets, 540 runs.

Outcomes: **pass**, the kit found nothing; **conformance-violation**, the kit's first disagreement with the reference; **refused-ValueError**, wardowl refused the data or a filter; **error**, anything else. Engines are checked one subject at a time; a run takes its worst subject's outcome. See benchmarks/paper/CONFORMANCE.md.

## Controls

- memory: not in these results.
- metadata-acl: not in these results.

## Violations

Wrong answers (leaks, filter and check disagreeing, altered metadata):

- none

Others:

- redis: after-set-metadata:missed in 10 runs (variants long-strings, huge-strings; seeds 0, 2, 9, 13, 15, 17-19)
- redis: missed in 16 runs (variants long-strings, huge-strings; seeds 0-1, 3-5, 7-8, 10-14, 19)

## Targets

Runs count one (seed, variant) each; sound-only retries of short exact answers are not counted here.

| Target | Family | Version | Status | Seeds | Runs | Pass | Violations | Refused | Errors |
|---|---|---|---|---:|---:|---:|---:|---:|---:|
| pgvector | store | `pgvector/pgvector:pg17`; {"pgvector": "0.8.7", "postgresql": "PostgreSQL 17.11 (Debian 17.11-1.pgdg12+2) on x86_64-pc-linux-gnu, compiled b...(+49 characters) | complete | 20 | 180 | 180 | 0 | 0 | 0 |
| redis | store | `redis:8.10.2-alpine`; {"modules": {}, "redis": "8.10.2"} | complete | 20 | 180 | 154 | 26 | 0 | 0 |
| cassandra | store | `cassandra:5.0.9`; {"cassandra": "5.0.9"} | complete | 20 | 180 | 180 | 0 | 0 | 0 |

## pgvector

exact search (no HNSW index, iterative_scan=None), one table truncated for every corpus, as CI.

Seeds 0-19; 10 corpora per seed for the default variant, 3 for the others; large corpora of up to 150 documents.

Image `pgvector/pgvector:pg17`, id `sha256:151aa1c2e849e7828ed8aef2183ae15f692cbe887d2f28921d8b44b26e154d7e`, digests ['pgvector/pgvector@sha256:ac08538c6f8b9904c33c8224c5e5706dbe760aca29db1d096972b4052c22a75d'].
Reported: `{"pgvector": "0.8.7", "postgresql": "PostgreSQL 17.11 (Debian 17.11-1.pgdg12+2) on x86_64-pc-linux-gnu, compiled by gcc (Debian 12.2.0-14+deb12u1) 12.2.0, 64-bit"}`.
Python packages: wardowl 2.1.0, psycopg 3.3.6, psycopg-pool 3.3.3.

| Variant | Mode | Seeds | Pass | Violations | Refused | Errors | Filters refused |
|---|---|---:|---:|---|---|---|---:|
| default | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| large-corpus | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| deep-filters | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| wide-or | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| long-strings | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| huge-strings | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| unicode-case | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| numeric-strings | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| odd-fields | exact | 20 | 20 | 0 | 0 | 0 | 0 |

## redis

a FLAT (exact) index and prefix for every corpus, as CI checks exactly.

Seeds 0-19; 10 corpora per seed for the default variant, 3 for the others; large corpora of up to 150 documents.

Image `redis:8.10.2-alpine`, id `sha256:6cfed4c686145bcd5807ef3ac1d2bf3384503cb3da30b0d308b4f25eb50dc373`, digests ['redis@sha256:0bf6577d7774e592b29d093e3ac9390eb91e13d72c21e506afce736de5e0eeb0'].
Reported: `{"modules": {}, "redis": "8.10.2"}`.
Python packages: wardowl 2.1.0, redis 8.1.0.

| Variant | Mode | Seeds | Pass | Violations | Refused | Errors | Filters refused |
|---|---|---:|---:|---|---|---|---:|
| default | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| large-corpus | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| deep-filters | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| wide-or | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| long-strings | exact | 20 | 10 | 10 (missed 6, after-set-metadata:missed 4) | 0 | 0 | 0 |
| long-strings | sound-retry | 10 | 10 | 0 | 0 | 0 | 0 |
| huge-strings | exact | 20 | 4 | 16 (missed 10, after-set-metadata:missed 6) | 0 | 0 | 0 |
| huge-strings | sound-retry | 16 | 16 | 0 | 0 | 0 | 0 |
| unicode-case | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| numeric-strings | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| odd-fields | exact | 20 | 20 | 0 | 0 | 0 | 0 |

The first run of each kind of failure:

- long-strings (exact), seed 0: **conformance-violation** missed. search with a filter (seed=0, example 2; rerun with the same seed to reproduce)
  Replay: `python benchmarks/paper/conformance_campaign.py run --targets redis --seed-list 0 --variants long-strings --examples 10 --stress-examples 3 --large-documents 150`
- long-strings (exact), seed 9: **conformance-violation** after-set-metadata:missed. search with a filter after set_metadata (seed=9, example 1; rerun with the same seed to reproduce)
  Replay: `python benchmarks/paper/conformance_campaign.py run --targets redis --seed-list 9 --variants long-strings --examples 10 --stress-examples 3 --large-documents 150`
- huge-strings (exact), seed 0: **conformance-violation** after-set-metadata:missed. search with a filter after set_metadata (seed=0, example 1; rerun with the same seed to reproduce)
  Replay: `python benchmarks/paper/conformance_campaign.py run --targets redis --seed-list 0 --variants huge-strings --examples 10 --stress-examples 3 --large-documents 150`
- huge-strings (exact), seed 1: **conformance-violation** missed. search with a filter (seed=1, example 0; rerun with the same seed to reproduce)
  Replay: `python benchmarks/paper/conformance_campaign.py run --targets redis --seed-list 1 --variants huge-strings --examples 10 --stress-examples 3 --large-documents 150`

## cassandra

sound-only (exact=False), as CI checks it: the jvector index is approximate; a table per corpus.

Seeds 0-19; 10 corpora per seed for the default variant, 3 for the others; large corpora of up to 150 documents.

Image `cassandra:5.0.9`, id `sha256:59994f7537a9801de015faf0ca1f89568421e3a83e9ebd7cccdf23727c3c4a99`, digests ['cassandra@sha256:3ea9333712c5692f3fe91d6c4dcc262df9e36338c4fdd1bc00a5e53f1137a1a0'].
Reported: `{"cassandra": "5.0.9"}`.
Python packages: wardowl 2.1.0, cassandra-driver 3.30.1.

| Variant | Mode | Seeds | Pass | Violations | Refused | Errors | Filters refused |
|---|---|---:|---:|---|---|---|---:|
| default | sound | 20 | 20 | 0 | 0 | 0 | 0 |
| large-corpus | sound | 20 | 20 | 0 | 0 | 0 | 0 |
| deep-filters | sound | 20 | 20 | 0 | 0 | 0 | 0 |
| wide-or | sound | 20 | 20 | 0 | 0 | 0 | 0 |
| long-strings | sound | 20 | 20 | 0 | 0 | 0 | 0 |
| huge-strings | sound | 20 | 20 | 0 | 0 | 0 | 0 |
| unicode-case | sound | 20 | 20 | 0 | 0 | 0 | 0 |
| numeric-strings | sound | 20 | 20 | 0 | 0 | 0 | 0 |
| odd-fields | sound | 20 | 20 | 0 | 0 | 0 | 0 |

