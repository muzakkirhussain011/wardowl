# Conformance campaign

wardowl 2.1.0 at commit `5d0f414a346511ad48a6c1c8b411259e6d908b84`, workflow run 40313285885, Python 3.12.15: 4 targets, 720 runs.

Outcomes: **pass**, the kit found nothing; **conformance-violation**, the kit's first disagreement with the reference; **refused-ValueError**, wardowl refused the data or a filter; **error**, anything else. Engines are checked one subject at a time; a run takes its worst subject's outcome. See benchmarks/paper/CONFORMANCE.md.

## Controls

- memory: not in these results.
- metadata-acl: not in these results.

## Violations

Wrong answers (leaks, filter and check disagreeing, altered metadata):

- none

Others:

- mongodb: after-set-metadata:missed in 9 runs (variants long-strings, huge-strings; seeds 0, 2, 9, 13, 15, 17-19)
- mongodb: missed in 10 runs (variants huge-strings; seeds 1, 3-5, 8, 10-14)

## Targets

Runs count one (seed, variant) each; sound-only retries of short exact answers are not counted here.

| Target | Family | Version | Status | Seeds | Runs | Pass | Violations | Refused | Errors |
|---|---|---|---|---:|---:|---:|---:|---:|---:|
| qdrant | store | `qdrant/qdrant:v1.19.2`; {"qdrant": "1.19.2"} | complete | 20 | 180 | 160 | 0 | 0 | 20 |
| milvus | store | `milvusdb/milvus:v3.0.2`; {"milvus": "3.0.2"} | complete | 20 | 180 | 140 | 0 | 0 | 40 |
| weaviate | store | `cr.weaviate.io/semitechnologies/weaviate:1.39.12`; {"weaviate": "1.39.12"} | complete | 20 | 180 | 180 | 0 | 0 | 0 |
| mongodb | store | `mongodb/mongodb-atlas-local:8.0.30`; {"mongodb": "8.0.30"} | complete | 20 | 180 | 161 | 19 | 0 | 0 |

## qdrant

the server, a collection for every corpus, as CI.

Seeds 0-19; 10 corpora per seed for the default variant, 3 for the others; large corpora of up to 150 documents.

Image `qdrant/qdrant:v1.19.2`, id `sha256:e37a07939a01ae09875d5cd58cd05a5e7c393151fce5e0a524c083835570e8e7`, digests ['qdrant/qdrant@sha256:b7b0444c4c351c970b98e90a6f89c2ee4287c65b44e52b4cb503fa5b2aa927ad'].
Reported: `{"qdrant": "1.19.2"}`.
Python packages: wardowl 2.1.0, qdrant-client 1.19.1.

| Variant | Mode | Seeds | Pass | Violations | Refused | Errors | Filters refused |
|---|---|---:|---:|---|---|---|---:|
| default | exact | 20 | 20 | 0 | 0 | 0 | 440 |
| large-corpus | exact | 20 | 20 | 0 | 0 | 0 | 197 |
| deep-filters | exact | 20 | 20 | 0 | 0 | 0 | 340 |
| wide-or | exact | 20 | 20 | 0 | 0 | 0 | 59 |
| long-strings | exact | 20 | 20 | 0 | 0 | 0 | 122 |
| huge-strings | exact | 20 | 20 | 0 | 0 | 0 | 133 |
| unicode-case | exact | 20 | 20 | 0 | 0 | 0 | 111 |
| numeric-strings | exact | 20 | 20 | 0 | 0 | 0 | 125 |
| odd-fields | exact | 20 | 0 | 0 | 0 | 20 (UnexpectedResponse 20) | 47 |

The first run of each kind of failure:

- odd-fields (exact), seed 0: **error** UnexpectedResponse. Unexpected Response: 400 (Bad Request)
  Replay: `python benchmarks/paper/conformance_campaign.py run --targets qdrant --seed-list 0 --variants odd-fields --examples 10 --stress-examples 3 --large-documents 150`

## milvus

standalone, a collection for every corpus, as CI.

Seeds 0-19; 10 corpora per seed for the default variant, 3 for the others; large corpora of up to 150 documents.

Image `milvusdb/milvus:v3.0.2`, id `sha256:544c055ed25a2d22e4d3366c7c6b6f8b2240494eee605994bd1988437fa27ac8`, digests ['milvusdb/milvus@sha256:5f13bf88e110a517911c3e6dd8172454e90042c21e606a868084615a4302c8a0'].
Reported: `{"milvus": "3.0.2"}`.
Python packages: wardowl 2.1.0, pymilvus 3.0.2.

| Variant | Mode | Seeds | Pass | Violations | Refused | Errors | Filters refused |
|---|---|---:|---:|---|---|---|---:|
| default | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| large-corpus | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| deep-filters | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| wide-or | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| long-strings | exact | 20 | 0 | 0 | 0 | 20 (MilvusException 20) | 0 |
| huge-strings | exact | 20 | 0 | 0 | 0 | 20 (MilvusException 20) | 0 |
| unicode-case | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| numeric-strings | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| odd-fields | exact | 20 | 20 | 0 | 0 | 0 | 0 |

The first run of each kind of failure:

- long-strings (exact), seed 0: **error** MilvusException. <MilvusException: (code=1100, message=length of Array array field "wardowl_terms" exceeds max length, row number: 0, array index: 1, length: 8199, max length: 1024: invalid parameter)>
  Replay: `python benchmarks/paper/conformance_campaign.py run --targets milvus --seed-list 0 --variants long-strings --examples 10 --stress-examples 3 --large-documents 150`
- huge-strings (exact), seed 0: **error** MilvusException. <MilvusException: (code=1100, message=the length (72841) of json field (metadata) exceeds max length (65536): invalid parameter[expected=valid length json string][actual=length exceeds max length])>
  Replay: `python benchmarks/paper/conformance_campaign.py run --targets milvus --seed-list 0 --variants huge-strings --examples 10 --stress-examples 3 --large-documents 150`

## weaviate

vectors from the client, a collection for every corpus, as CI.

Seeds 0-19; 10 corpora per seed for the default variant, 3 for the others; large corpora of up to 150 documents.

Image `cr.weaviate.io/semitechnologies/weaviate:1.39.12`, id `sha256:21f12a8c5e76a5a17d8df4a0d7b5ef382e559987355201b9a8869893da66d082`, digests ['cr.weaviate.io/semitechnologies/weaviate@sha256:2bc7ebd9aabc34f9d99602c42ffa274cd086110694895197893331f95462c671'].
Reported: `{"weaviate": "1.39.12"}`.
Python packages: wardowl 2.1.0, weaviate-client 4.23.1.

| Variant | Mode | Seeds | Pass | Violations | Refused | Errors | Filters refused |
|---|---|---:|---:|---|---|---|---:|
| default | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| large-corpus | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| deep-filters | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| wide-or | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| long-strings | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| huge-strings | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| unicode-case | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| numeric-strings | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| odd-fields | exact | 20 | 20 | 0 | 0 | 0 | 0 |

## mongodb

a local Atlas deployment, one collection and vector index for every corpus in turn, as CI.

Seeds 0-19; 10 corpora per seed for the default variant, 3 for the others; large corpora of up to 150 documents.

Image `mongodb/mongodb-atlas-local:8.0.30`, id `sha256:2c3d0f74e5c2037bb0d64843cd34de380180874535a87db01ccdbc7468d0a54d`, digests ['mongodb/mongodb-atlas-local@sha256:ced636f193a3420a46bc8c80a0e42edd9a8daa96c425b78a5bb49258b56b824c'].
Reported: `{"mongodb": "8.0.30"}`.
Python packages: wardowl 2.1.0, pymongo 4.19.0.

| Variant | Mode | Seeds | Pass | Violations | Refused | Errors | Filters refused |
|---|---|---:|---:|---|---|---|---:|
| default | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| large-corpus | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| deep-filters | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| wide-or | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| long-strings | exact | 20 | 17 | 3 (after-set-metadata:missed 3) | 0 | 0 | 0 |
| long-strings | sound-retry | 3 | 3 | 0 | 0 | 0 | 0 |
| huge-strings | exact | 20 | 4 | 16 (missed 10, after-set-metadata:missed 6) | 0 | 0 | 0 |
| huge-strings | sound-retry | 16 | 16 | 0 | 0 | 0 | 0 |
| unicode-case | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| numeric-strings | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| odd-fields | exact | 20 | 20 | 0 | 0 | 0 | 0 |

The first run of each kind of failure:

- long-strings (exact), seed 13: **conformance-violation** after-set-metadata:missed. search with a filter after set_metadata (seed=13, example 0; rerun with the same seed to reproduce)
  Replay: `python benchmarks/paper/conformance_campaign.py run --targets mongodb --seed-list 13 --variants long-strings --examples 10 --stress-examples 3 --large-documents 150`
- huge-strings (exact), seed 0: **conformance-violation** after-set-metadata:missed. search with a filter after set_metadata (seed=0, example 1; rerun with the same seed to reproduce)
  Replay: `python benchmarks/paper/conformance_campaign.py run --targets mongodb --seed-list 0 --variants huge-strings --examples 10 --stress-examples 3 --large-documents 150`
- huge-strings (exact), seed 1: **conformance-violation** missed. search with a filter (seed=1, example 0; rerun with the same seed to reproduce)
  Replay: `python benchmarks/paper/conformance_campaign.py run --targets mongodb --seed-list 1 --variants huge-strings --examples 10 --stress-examples 3 --large-documents 150`

