# Conformance campaign

wardowl 2.1.0 at commit `182bcbc53b9135c1c9bca4f0652a0f94ff2b9938`, workflow run 40905549149, Python 3.12.15: 1 targets, 0 runs.

Outcomes: **pass**, the kit found nothing; **conformance-violation**, the kit's first disagreement with the reference; **refused-ValueError**, wardowl refused the data or a filter; **error**, anything else. Engines are checked one subject at a time; a run takes its worst subject's outcome. Every run that did not pass is in its group's artifact, findings/<target>.txt, with the whole message. See benchmarks/paper/CONFORMANCE.md.

## Controls

- memory: not in these results.
- metadata-acl: not in these results.

## Violations

Wrong answers (leaks, filter and check disagreeing, altered metadata):

- none

Others:

- none

## Targets

Runs count one (seed, variant) each; sound-only retries of short exact answers are not counted here.

| Target | Family | Version | Status | Seeds | Runs | Pass | Violations | Refused | Errors |
|---|---|---|---|---:|---:|---:|---:|---:|---:|
| pinecone | store | httpx 0.28.1 | skipped: the PINECONE_API_KEY secret is not set | 0 | 0 | 0 | 0 | 0 | 0 |

## pinecone

the service: CI's index wardowl-ci, a namespace for every corpus, writes waited for up to 60 s.

Seeds 0-19; 4 corpora per seed for the default variant, 2 for the others; large corpora of up to 40 documents.

Python packages: wardowl 2.1.0, httpx 0.28.1.

No runs.

