# Conformance campaign

wardowl 2.1.0 at commit `182bcbc53b9135c1c9bca4f0652a0f94ff2b9938`, workflow run 40905549149, Python 3.12.15: 1 targets, 70 runs.

Outcomes: **pass**, the kit found nothing; **conformance-violation**, the kit's first disagreement with the reference; **refused-ValueError**, wardowl refused the data or a filter; **error**, anything else. Engines are checked one subject at a time; a run takes its worst subject's outcome. Every run that did not pass is in its group's artifact, findings/<target>.txt, with the whole message. See benchmarks/paper/CONFORMANCE.md.

## Controls

- memory: not in these results.
- metadata-acl: not in these results.

## Violations

Wrong answers (leaks, filter and check disagreeing, altered metadata):

- none

Others:

- none

## Targets

Runs count one (seed, variant) each; sound-only retries of short exact answers are not counted here.

| Target | Family | Version | Status | Seeds | Runs | Pass | Violations | Refused | Errors |
|---|---|---|---|---:|---:|---:|---:|---:|---:|
| casbin | engine | casbin 1.43.0 | complete | 10 | 70 | 70 | 0 | 0 | 0 |

## casbin

the RBAC model of wardowl's tests with '*' for everyone, a policy row per grant, groups from the subject (group_subjects=True), in process.

Seeds 10-19; 10 corpora per seed for the default variant, 3 for the others; large corpora of up to 150 documents.

Python packages: wardowl 2.1.0, casbin 1.43.0.

| Variant | Mode | Seeds | Pass | Violations | Refused | Errors | Subjects passing |
|---|---|---:|---:|---|---|---|---:|
| default | consistency | 10 | 10 | 0 | 0 | 0 | 120/120 |
| unicode-case | consistency | 10 | 10 | 0 | 0 | 0 | 80/80 |
| numeric-strings | consistency | 10 | 10 | 0 | 0 | 0 | 80/80 |
| many-groups | consistency | 10 | 10 | 0 | 0 | 0 | 30/30 |
| many-hits | consistency | 10 | 10 | 0 | 0 | 0 | 40/40 |
| long-ids | consistency | 10 | 10 | 0 | 0 | 0 | 80/80 |
| scalar-fields | consistency | 10 | 10 | 0 | 0 | 0 | 80/80 |

