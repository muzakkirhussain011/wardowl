# Conformance campaign

wardowl 2.1.0 at commit `182bcbc53b9135c1c9bca4f0652a0f94ff2b9938`, workflow run 40905549149, Python 3.12.15: 1 targets, 140 runs.

Outcomes: **pass**, the kit found nothing; **conformance-violation**, the kit's first disagreement with the reference; **refused-ValueError**, wardowl refused the data or a filter; **error**, anything else. Engines are checked one subject at a time; a run takes its worst subject's outcome. Every run that did not pass is in its group's artifact, findings/<target>.txt, with the whole message. See benchmarks/paper/CONFORMANCE.md.

## Controls

- memory: not in these results.
- metadata-acl: not in these results.

## Violations

Wrong answers (leaks, filter and check disagreeing, altered metadata):

- none

Others:

- none

## Targets

Runs count one (seed, variant) each; sound-only retries of short exact answers are not counted here.

| Target | Family | Version | Status | Seeds | Runs | Pass | Violations | Refused | Errors |
|---|---|---|---|---:|---:|---:|---:|---:|---:|
| keto | engine | `oryd/keto:v26.2.0`; {"keto": "v26.2.0"} | complete | 20 | 140 | 140 | 0 | 0 | 0 |

## keto

acceptance/policies/keto (Document#view of users and Group#members), tuples replaced for every run, groups checked as subject sets (group_subjects=True), Keto's default batch limit of 10.

Seeds 0-19; 10 corpora per seed for the default variant, 3 for the others; large corpora of up to 150 documents.

Image `oryd/keto:v26.2.0`, id `sha256:0c325feb33d9de6016aa3e628c7bcfa5415f09ab808bbc2db42e58af286bca22`, digests ['oryd/keto@sha256:bfdb8b9e283aedbd9e1d005c44eb1bbefd2096b2cb5b5aa0b7360b6e39c178d2'].
Reported: `{"keto": "v26.2.0"}`.
Python packages: wardowl 2.1.0.

| Variant | Mode | Seeds | Pass | Violations | Refused | Errors | Subjects passing |
|---|---|---:|---:|---|---|---|---:|
| default | consistency | 20 | 20 | 0 | 0 | 0 | 240/240 |
| unicode-case | consistency | 20 | 20 | 0 | 0 | 0 | 160/160 |
| numeric-strings | consistency | 20 | 20 | 0 | 0 | 0 | 160/160 |
| many-groups | consistency | 20 | 20 | 0 | 0 | 0 | 60/60 |
| many-hits | consistency | 20 | 20 | 0 | 0 | 0 | 80/80 |
| long-ids | consistency | 20 | 20 | 0 | 0 | 0 | 160/160 |
| scalar-fields | consistency | 20 | 20 | 0 | 0 | 0 | 160/160 |

