# Conformance campaign

wardowl 2.1.0 at commit `182bcbc53b9135c1c9bca4f0652a0f94ff2b9938`, workflow run 40905549149, Python 3.12.15: 12 targets, 1680 runs.

Outcomes: **pass**, the kit found nothing; **conformance-violation**, the kit's first disagreement with the reference; **refused-ValueError**, wardowl refused the data or a filter; **error**, anything else. Engines are checked one subject at a time; a run takes its worst subject's outcome. Every run that did not pass is in its group's artifact, findings/<target>.txt, with the whole message. See benchmarks/paper/CONFORMANCE.md.

## Controls

- memory: not in these results.
- metadata-acl: 140 of 140 runs pass.

## Violations

Wrong answers (leaks, filter and check disagreeing, altered metadata):

- cerbos: filter-check-disagree in 20 runs (variants scalar-fields; seeds 0-19)
  - 235 disagreeing hits: the filter gives the reference answer for 235, check for 0
- cerbos-tenant: filter-check-disagree in 19 runs (variants scalar-fields; seeds 0-10, 12-19)
  - 45 disagreeing hits: the filter gives the reference answer for 45, check for 0

Others:

- none

## Targets

Runs count one (seed, variant) each; sound-only retries of short exact answers are not counted here.

| Target | Family | Version | Status | Seeds | Runs | Pass | Violations | Refused | Errors |
|---|---|---|---|---:|---:|---:|---:|---:|---:|
| metadata-acl | engine |  | complete | 20 | 140 | 140 | 0 | 0 | 0 |
| opa | engine | {"opa": "Version: 1.21.2", "server": "1.21.2"} | complete | 20 | 140 | 140 | 0 | 0 | 0 |
| opa-tenant | engine | {"opa": "Version: 1.21.2", "server": "1.21.2"} | complete | 20 | 140 | 140 | 0 | 0 | 0 |
| openfga | engine | `openfga/openfga:v1.22.0` | complete | 20 | 140 | 21 | 0 | 119 | 0 |
| openfga-tenant | engine | `openfga/openfga:v1.22.0` | complete | 20 | 140 | 21 | 0 | 119 | 0 |
| spicedb | engine | `authzed/spicedb:v1.56.2` | complete | 20 | 140 | 16 | 0 | 124 | 0 |
| spicedb-tenant | engine | `authzed/spicedb:v1.56.2` | complete | 20 | 140 | 23 | 0 | 117 | 0 |
| cerbos | engine | `ghcr.io/cerbos/cerbos:0.56.0`; {"buildDate": "2026-09-30T06:22:34Z", "commit": "98604d71b79dafdc16ac57e4712fc435227e7c0f", "version": "0.56...(+4 characters) | complete | 20 | 140 | 120 | 20 | 0 | 0 |
| cerbos-tenant | engine | `ghcr.io/cerbos/cerbos:0.56.0`; {"buildDate": "2026-09-30T06:22:34Z", "commit": "98604d71b79dafdc16ac57e4712fc435227e7c0f", "version": "0.56...(+4 characters) | complete | 20 | 140 | 121 | 19 | 0 | 0 |
| cedar | engine | cedarpy 4.12.2 | complete | 20 | 140 | 140 | 0 | 0 | 0 |
| cedar-tenant | engine | cedarpy 4.12.2 | complete | 20 | 140 | 140 | 0 | 0 | 0 |
| casbin-tenant | engine | casbin 1.43.0 | complete | 20 | 140 | 140 | 0 | 0 | 0 |

## metadata-acl

MetadataACLAuthorizer, in process: the positive control.

Seeds 0-19; 10 corpora per seed for the default variant, 3 for the others; large corpora of up to 150 documents.

Python packages: wardowl 2.1.0.

| Variant | Mode | Seeds | Pass | Violations | Refused | Errors | Subjects passing |
|---|---|---:|---:|---|---|---|---:|
| default | consistency | 20 | 20 | 0 | 0 | 0 | 240/240 |
| unicode-case | consistency | 20 | 20 | 0 | 0 | 0 | 160/160 |
| numeric-strings | consistency | 20 | 20 | 0 | 0 | 0 | 160/160 |
| many-groups | consistency | 20 | 20 | 0 | 0 | 0 | 60/60 |
| many-hits | consistency | 20 | 20 | 0 | 0 | 0 | 80/80 |
| long-ids | consistency | 20 | 20 | 0 | 0 | 0 | 160/160 |
| scalar-fields | consistency | 20 | 20 | 0 | 0 | 0 | 160/160 |

## opa

examples/opa/wardowl.rego, loaded at startup as CI loads it, with filter_path wardowl/filter.

Seeds 0-19; 10 corpora per seed for the default variant, 3 for the others; large corpora of up to 150 documents.

Reported: `{"opa": "Version: 1.21.2", "server": "1.21.2"}`.
Python packages: wardowl 2.1.0.

| Variant | Mode | Seeds | Pass | Violations | Refused | Errors | Subjects passing |
|---|---|---:|---:|---|---|---|---:|
| default | consistency | 20 | 20 | 0 | 0 | 0 | 240/240 |
| unicode-case | consistency | 20 | 20 | 0 | 0 | 0 | 160/160 |
| numeric-strings | consistency | 20 | 20 | 0 | 0 | 0 | 160/160 |
| many-groups | consistency | 20 | 20 | 0 | 0 | 0 | 60/60 |
| many-hits | consistency | 20 | 20 | 0 | 0 | 0 | 80/80 |
| long-ids | consistency | 20 | 20 | 0 | 0 | 0 | 160/160 |
| scalar-fields | consistency | 20 | 20 | 0 | 0 | 0 | 160/160 |

## opa-tenant

acceptance/policies/opa/documents.rego, uploaded under a package of the run's own, with the sharing of every chunk pushed as OPA data; its filter_path returns an In on doc_id.

Seeds 0-19; 10 corpora per seed for the default variant, 3 for the others; large corpora of up to 150 documents.

Reported: `{"opa": "Version: 1.21.2", "server": "1.21.2"}`.
Python packages: wardowl 2.1.0.

| Variant | Mode | Seeds | Pass | Violations | Refused | Errors | Subjects passing |
|---|---|---:|---:|---|---|---|---:|
| default | consistency | 20 | 20 | 0 | 0 | 0 | 240/240 |
| unicode-case | consistency | 20 | 20 | 0 | 0 | 0 | 160/160 |
| numeric-strings | consistency | 20 | 20 | 0 | 0 | 0 | 160/160 |
| many-groups | consistency | 20 | 20 | 0 | 0 | 0 | 60/60 |
| many-hits | consistency | 20 | 20 | 0 | 0 | 0 | 80/80 |
| long-ids | consistency | 20 | 20 | 0 | 0 | 0 | 160/160 |
| scalar-fields | consistency | 20 | 20 | 0 | 0 | 0 | 160/160 |

## openfga

the model of wardowl's tests (user, user:*, group#member viewers), a store per run, a tuple per grant in the chunks' ACLs; groups as contextual tuples; HIGHER_CONSISTENCY.

Seeds 0-19; 10 corpora per seed for the default variant, 3 for the others; large corpora of up to 150 documents.

Image `openfga/openfga:v1.22.0`, id `sha256:6da24ff138aff7a2fe5273819516d52ca2103086d909338531e13cb3b7c9b943`, digests ['openfga/openfga@sha256:9cf9a20af32a40434cd3a788c429879439ee9ea9abf65c9c200ee17cd43f769e'].
Python packages: wardowl 2.1.0.

| Variant | Mode | Seeds | Pass | Violations | Refused | Errors | Subjects passing |
|---|---|---:|---:|---|---|---|---:|
| default | consistency | 20 | 2 | 0 | 18 (UnsupportedSubject 18) | 0 | 198/240 |
| unicode-case | consistency | 20 | 4 | 0 | 16 (UnsupportedSubject 16) | 0 | 129/160 |
| numeric-strings | consistency | 20 | 3 | 0 | 17 (UnsupportedSubject 17) | 0 | 125/160 |
| many-groups | consistency | 20 | 0 | 0 | 20 (UnsupportedSubject 20) | 0 | 0/60 |
| many-hits | consistency | 20 | 8 | 0 | 12 (UnsupportedSubject 12) | 0 | 68/80 |
| long-ids | consistency | 20 | 0 | 0 | 20 (UnsupportedSubject 20) | 0 | 48/160 |
| scalar-fields | consistency | 20 | 4 | 0 | 16 (UnsupportedSubject 16) | 0 | 134/160 |

The first run of each kind of failure:

- default (consistency), seed 0: **refused-ValueError** UnsupportedSubject. subject 'alice' is in 301 groups, which cannot be sent to OpenFGA: it takes at most 100 contextual tuples per check; store the memberships in OpenFGA and set contextual_groups=False
  Replay: `python benchmarks/paper/conformance_campaign.py run --targets openfga --seed-list 0 --variants default --examples 10 --stress-examples 3 --large-documents 150`
- unicode-case (consistency), seed 0: **refused-ValueError** UnsupportedSubject. subject 'Bob' is in 302 groups, which cannot be sent to OpenFGA: it takes at most 100 contextual tuples per check; store the memberships in OpenFGA and set contextual_groups=False
  Replay: `python benchmarks/paper/conformance_campaign.py run --targets openfga --seed-list 0 --variants unicode-case --examples 10 --stress-examples 3 --large-documents 150`
- numeric-strings (consistency), seed 0: **refused-ValueError** UnsupportedSubject. subject '7.0' is in 303 groups, which cannot be sent to OpenFGA: it takes at most 100 contextual tuples per check; store the memberships in OpenFGA and set contextual_groups=False
  Replay: `python benchmarks/paper/conformance_campaign.py run --targets openfga --seed-list 0 --variants numeric-strings --examples 10 --stress-examples 3 --large-documents 150`
- many-groups (consistency), seed 0: **refused-ValueError** UnsupportedSubject. subject 'Bob' is in 1,002 groups, which cannot be sent to OpenFGA: it takes at most 100 contextual tuples per check; store the memberships in OpenFGA and set contextual_groups=False
  Replay: `python benchmarks/paper/conformance_campaign.py run --targets openfga --seed-list 0 --variants many-groups --examples 10 --stress-examples 3 --large-documents 150`
- many-hits (consistency), seed 0: **refused-ValueError** UnsupportedSubject. subject 'dave' is in 301 groups, which cannot be sent to OpenFGA: it takes at most 100 contextual tuples per check; store the memberships in OpenFGA and set contextual_groups=False
  Replay: `python benchmarks/paper/conformance_campaign.py run --targets openfga --seed-list 0 --variants many-hits --examples 10 --stress-examples 3 --large-documents 150`
- long-ids (consistency), seed 0: **refused-ValueError** UnsupportedSubject. group 'gggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggg'... (256 characters) cannot be sent to OpenFGA: group:<group> is longer than 256 characters
  Replay: `python benchmarks/paper/conformance_campaign.py run --targets openfga --seed-list 0 --variants long-ids --examples 10 --stress-examples 3 --large-documents 150`
- scalar-fields (consistency), seed 0: **refused-ValueError** UnsupportedSubject. subject 'alice' is in 300 groups, which cannot be sent to OpenFGA: it takes at most 100 contextual tuples per check; store the memberships in OpenFGA and set contextual_groups=False
  Replay: `python benchmarks/paper/conformance_campaign.py run --targets openfga --seed-list 0 --variants scalar-fields --examples 10 --stress-examples 3 --large-documents 150`

## openfga-tenant

acceptance/policies/openfga/model.json (a tenant intersection), a store per run, tuples for each subject's tenant and each chunk's tenant and readers; groups as contextual tuples; HIGHER_CONSISTENCY.

Seeds 0-19; 10 corpora per seed for the default variant, 3 for the others; large corpora of up to 150 documents.

Image `openfga/openfga:v1.22.0`, id `sha256:6da24ff138aff7a2fe5273819516d52ca2103086d909338531e13cb3b7c9b943`, digests ['openfga/openfga@sha256:9cf9a20af32a40434cd3a788c429879439ee9ea9abf65c9c200ee17cd43f769e'].
Python packages: wardowl 2.1.0.

| Variant | Mode | Seeds | Pass | Violations | Refused | Errors | Subjects passing |
|---|---|---:|---:|---|---|---|---:|
| default | consistency | 20 | 2 | 0 | 18 (UnsupportedSubject 18) | 0 | 198/240 |
| unicode-case | consistency | 20 | 4 | 0 | 16 (UnsupportedSubject 16) | 0 | 129/160 |
| numeric-strings | consistency | 20 | 3 | 0 | 17 (UnsupportedSubject 17) | 0 | 125/160 |
| many-groups | consistency | 20 | 0 | 0 | 20 (UnsupportedSubject 20) | 0 | 0/60 |
| many-hits | consistency | 20 | 8 | 0 | 12 (UnsupportedSubject 12) | 0 | 68/80 |
| long-ids | consistency | 20 | 0 | 0 | 20 (UnsupportedSubject 20) | 0 | 48/160 |
| scalar-fields | consistency | 20 | 4 | 0 | 16 (UnsupportedSubject 16) | 0 | 134/160 |

The first run of each kind of failure:

- default (consistency), seed 0: **refused-ValueError** UnsupportedSubject. subject 'alice' is in 301 groups, which cannot be sent to OpenFGA: it takes at most 100 contextual tuples per check; store the memberships in OpenFGA and set contextual_groups=False
  Replay: `python benchmarks/paper/conformance_campaign.py run --targets openfga-tenant --seed-list 0 --variants default --examples 10 --stress-examples 3 --large-documents 150`
- unicode-case (consistency), seed 0: **refused-ValueError** UnsupportedSubject. subject 'Bob' is in 302 groups, which cannot be sent to OpenFGA: it takes at most 100 contextual tuples per check; store the memberships in OpenFGA and set contextual_groups=False
  Replay: `python benchmarks/paper/conformance_campaign.py run --targets openfga-tenant --seed-list 0 --variants unicode-case --examples 10 --stress-examples 3 --large-documents 150`
- numeric-strings (consistency), seed 0: **refused-ValueError** UnsupportedSubject. subject '7.0' is in 303 groups, which cannot be sent to OpenFGA: it takes at most 100 contextual tuples per check; store the memberships in OpenFGA and set contextual_groups=False
  Replay: `python benchmarks/paper/conformance_campaign.py run --targets openfga-tenant --seed-list 0 --variants numeric-strings --examples 10 --stress-examples 3 --large-documents 150`
- many-groups (consistency), seed 0: **refused-ValueError** UnsupportedSubject. subject 'Bob' is in 1,002 groups, which cannot be sent to OpenFGA: it takes at most 100 contextual tuples per check; store the memberships in OpenFGA and set contextual_groups=False
  Replay: `python benchmarks/paper/conformance_campaign.py run --targets openfga-tenant --seed-list 0 --variants many-groups --examples 10 --stress-examples 3 --large-documents 150`
- many-hits (consistency), seed 0: **refused-ValueError** UnsupportedSubject. subject 'dave' is in 301 groups, which cannot be sent to OpenFGA: it takes at most 100 contextual tuples per check; store the memberships in OpenFGA and set contextual_groups=False
  Replay: `python benchmarks/paper/conformance_campaign.py run --targets openfga-tenant --seed-list 0 --variants many-hits --examples 10 --stress-examples 3 --large-documents 150`
- long-ids (consistency), seed 0: **refused-ValueError** UnsupportedSubject. group 'gggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggg'... (256 characters) cannot be sent to OpenFGA: group:<group> is longer than 256 characters
  Replay: `python benchmarks/paper/conformance_campaign.py run --targets openfga-tenant --seed-list 0 --variants long-ids --examples 10 --stress-examples 3 --large-documents 150`
- scalar-fields (consistency), seed 0: **refused-ValueError** UnsupportedSubject. subject 'alice' is in 300 groups, which cannot be sent to OpenFGA: it takes at most 100 contextual tuples per check; store the memberships in OpenFGA and set contextual_groups=False
  Replay: `python benchmarks/paper/conformance_campaign.py run --targets openfga-tenant --seed-list 0 --variants scalar-fields --examples 10 --stress-examples 3 --large-documents 150`

## spicedb

the schema of wardowl's tests (user, user:*, group#member viewers), groups checked as subject sets (group_subjects=True), fully consistent.

Seeds 0-19; 10 corpora per seed for the default variant, 3 for the others; large corpora of up to 150 documents.

Image `authzed/spicedb:v1.56.2`, id `sha256:3bad3b99cc5d01cbe99a8974921cdef45625f5b544c343432549485bb182e811`, digests ['authzed/spicedb@sha256:aa96009a0477f8a759149823407d47ad16d1a74390bae3102b3b0b7143502764'].
Python packages: wardowl 2.1.0.

| Variant | Mode | Seeds | Pass | Violations | Refused | Errors | Subjects passing |
|---|---|---:|---:|---|---|---|---:|
| default | consistency | 20 | 1 | 0 | 19 (UnsupportedSubject 19) | 0 | 165/240 |
| unicode-case | consistency | 20 | 0 | 0 | 20 (UnsupportedSubject 20) | 0 | 41/160 |
| numeric-strings | consistency | 20 | 0 | 0 | 20 (UnsupportedSubject 20) | 0 | 52/160 |
| many-groups | consistency | 20 | 5 | 0 | 15 (UnsupportedSubject 15) | 0 | 35/60 |
| many-hits | consistency | 20 | 5 | 0 | 15 (UnsupportedSubject 15) | 0 | 56/80 |
| long-ids | consistency | 20 | 3 | 0 | 17 (UnsupportedSubject 17) | 0 | 122/160 |
| scalar-fields | consistency | 20 | 2 | 0 | 18 (UnsupportedSubject 18) | 0 | 118/160 |

The first run of each kind of failure:

- default (consistency), seed 0: **refused-ValueError** UnsupportedSubject. subject id 'zoë' cannot be sent to SpiceDB: object ids are 1 to 1024 letters, digits and /_\|-=+
  Replay: `python benchmarks/paper/conformance_campaign.py run --targets spicedb --seed-list 0 --variants default --examples 10 --stress-examples 3 --large-documents 150`
- unicode-case (consistency), seed 0: **refused-ValueError** UnsupportedSubject. group 'ß' cannot be sent to SpiceDB: object ids are 1 to 1024 letters, digits and /_\|-=+
  Replay: `python benchmarks/paper/conformance_campaign.py run --targets spicedb --seed-list 0 --variants unicode-case --examples 10 --stress-examples 3 --large-documents 150`
- numeric-strings (consistency), seed 0: **refused-ValueError** UnsupportedSubject. subject id '7.0' cannot be sent to SpiceDB: object ids are 1 to 1024 letters, digits and /_\|-=+
  Replay: `python benchmarks/paper/conformance_campaign.py run --targets spicedb --seed-list 0 --variants numeric-strings --examples 10 --stress-examples 3 --large-documents 150`
- many-groups (consistency), seed 0: **refused-ValueError** UnsupportedSubject. subject id 'zoë' cannot be sent to SpiceDB: object ids are 1 to 1024 letters, digits and /_\|-=+
  Replay: `python benchmarks/paper/conformance_campaign.py run --targets spicedb --seed-list 0 --variants many-groups --examples 10 --stress-examples 3 --large-documents 150`
- many-hits (consistency), seed 1: **refused-ValueError** UnsupportedSubject. subject id 'zoë' cannot be sent to SpiceDB: object ids are 1 to 1024 letters, digits and /_\|-=+
  Replay: `python benchmarks/paper/conformance_campaign.py run --targets spicedb --seed-list 1 --variants many-hits --examples 10 --stress-examples 3 --large-documents 150`
- long-ids (consistency), seed 0: **refused-ValueError** UnsupportedSubject. group 'gggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggg'... (4,096 characters) cannot be sent to SpiceDB: object ids are 1 to 1024 letters, digits and /_\|-=+
  Replay: `python benchmarks/paper/conformance_campaign.py run --targets spicedb --seed-list 0 --variants long-ids --examples 10 --stress-examples 3 --large-documents 150`
- scalar-fields (consistency), seed 1: **refused-ValueError** UnsupportedSubject. subject id 'zoë' cannot be sent to SpiceDB: object ids are 1 to 1024 letters, digits and /_\|-=+
  Replay: `python benchmarks/paper/conformance_campaign.py run --targets spicedb --seed-list 1 --variants scalar-fields --examples 10 --stress-examples 3 --large-documents 150`

## spicedb-tenant

acceptance/policies/spicedb/schema.zed (view = reader & tenant->member), memberships stored in SpiceDB, group_subjects=False, fully consistent.

Seeds 0-19; 10 corpora per seed for the default variant, 3 for the others; large corpora of up to 150 documents.

Image `authzed/spicedb:v1.56.2`, id `sha256:3bad3b99cc5d01cbe99a8974921cdef45625f5b544c343432549485bb182e811`, digests ['authzed/spicedb@sha256:aa96009a0477f8a759149823407d47ad16d1a74390bae3102b3b0b7143502764'].
Python packages: wardowl 2.1.0.

| Variant | Mode | Seeds | Pass | Violations | Refused | Errors | Subjects passing |
|---|---|---:|---:|---|---|---|---:|
| default | consistency | 20 | 1 | 0 | 19 (UnsupportedSubject 19) | 0 | 165/240 |
| unicode-case | consistency | 20 | 0 | 0 | 20 (UnsupportedSubject 20) | 0 | 84/160 |
| numeric-strings | consistency | 20 | 0 | 0 | 20 (UnsupportedSubject 20) | 0 | 93/160 |
| many-groups | consistency | 20 | 5 | 0 | 15 (UnsupportedSubject 15) | 0 | 35/60 |
| many-hits | consistency | 20 | 5 | 0 | 15 (UnsupportedSubject 15) | 0 | 56/80 |
| long-ids | consistency | 20 | 10 | 0 | 10 (UnsupportedSubject 10) | 0 | 143/160 |
| scalar-fields | consistency | 20 | 2 | 0 | 18 (UnsupportedSubject 18) | 0 | 118/160 |

The first run of each kind of failure:

- default (consistency), seed 0: **refused-ValueError** UnsupportedSubject. subject id 'zoë' cannot be sent to SpiceDB: object ids are 1 to 1024 letters, digits and /_\|-=+
  Replay: `python benchmarks/paper/conformance_campaign.py run --targets spicedb-tenant --seed-list 0 --variants default --examples 10 --stress-examples 3 --large-documents 150`
- unicode-case (consistency), seed 0: **refused-ValueError** UnsupportedSubject. subject id 'zoë' cannot be sent to SpiceDB: object ids are 1 to 1024 letters, digits and /_\|-=+
  Replay: `python benchmarks/paper/conformance_campaign.py run --targets spicedb-tenant --seed-list 0 --variants unicode-case --examples 10 --stress-examples 3 --large-documents 150`
- numeric-strings (consistency), seed 0: **refused-ValueError** UnsupportedSubject. subject id '7.0' cannot be sent to SpiceDB: object ids are 1 to 1024 letters, digits and /_\|-=+
  Replay: `python benchmarks/paper/conformance_campaign.py run --targets spicedb-tenant --seed-list 0 --variants numeric-strings --examples 10 --stress-examples 3 --large-documents 150`
- many-groups (consistency), seed 0: **refused-ValueError** UnsupportedSubject. subject id 'zoë' cannot be sent to SpiceDB: object ids are 1 to 1024 letters, digits and /_\|-=+
  Replay: `python benchmarks/paper/conformance_campaign.py run --targets spicedb-tenant --seed-list 0 --variants many-groups --examples 10 --stress-examples 3 --large-documents 150`
- many-hits (consistency), seed 1: **refused-ValueError** UnsupportedSubject. subject id 'zoë' cannot be sent to SpiceDB: object ids are 1 to 1024 letters, digits and /_\|-=+
  Replay: `python benchmarks/paper/conformance_campaign.py run --targets spicedb-tenant --seed-list 1 --variants many-hits --examples 10 --stress-examples 3 --large-documents 150`
- long-ids (consistency), seed 0: **refused-ValueError** UnsupportedSubject. subject id 'uuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuu'... (4,096 characters) cannot be sent to SpiceDB: object ids are 1 to 1024 letters, digits and /_\|-=+
  Replay: `python benchmarks/paper/conformance_campaign.py run --targets spicedb-tenant --seed-list 0 --variants long-ids --examples 10 --stress-examples 3 --large-documents 150`
- scalar-fields (consistency), seed 1: **refused-ValueError** UnsupportedSubject. subject id 'zoë' cannot be sent to SpiceDB: object ids are 1 to 1024 letters, digits and /_\|-=+
  Replay: `python benchmarks/paper/conformance_campaign.py run --targets spicedb-tenant --seed-list 1 --variants scalar-fields --examples 10 --stress-examples 3 --large-documents 150`

## cerbos

examples/cerbos/policies/document.yaml (metadata ACLs), loaded at startup as CI loads it.

Seeds 0-19; 10 corpora per seed for the default variant, 3 for the others; large corpora of up to 150 documents.

Image `ghcr.io/cerbos/cerbos:0.56.0`, id `sha256:9769be8555e0d7a5bf8da1d9b5bb6b64dfa7a8350a6a42d752e7dae7cbc6e584`, digests ['ghcr.io/cerbos/cerbos@sha256:540643bc67ba628011a150ad1d3370f285daa38995be5cd7a4be181da902bec1'].
Reported: `{"buildDate": "2026-09-30T06:22:34Z", "commit": "98604d71b79dafdc16ac57e4712fc435227e7c0f", "version": "0.56.0"}`.
Python packages: wardowl 2.1.0.

| Variant | Mode | Seeds | Pass | Violations | Refused | Errors | Subjects passing |
|---|---|---:|---:|---|---|---|---:|
| default | consistency | 20 | 20 | 0 | 0 | 0 | 240/240 |
| unicode-case | consistency | 20 | 20 | 0 | 0 | 0 | 160/160 |
| numeric-strings | consistency | 20 | 20 | 0 | 0 | 0 | 160/160 |
| many-groups | consistency | 20 | 20 | 0 | 0 | 0 | 60/60 |
| many-hits | consistency | 20 | 20 | 0 | 0 | 0 | 80/80 |
| long-ids | consistency | 20 | 20 | 0 | 0 | 0 | 160/160 |
| scalar-fields | consistency | 20 | 0 | 20 (filter-check-disagree 20) | 0 | 0 | 33/160 |

The first run of each kind of failure:

- scalar-fields (consistency), seed 0: **conformance-violation** filter-check-disagree. filter_for and check disagree (seed=0, example 0; rerun with the same seed to reproduce)
  Disagreeing hit: carol, doc-024 {"allowed_groups": "Eng", "doc_id": "doc-024"}: the filter allows, check denies; the reference allows, as the filter does
  Disagreeing hit: carol, doc-007 {"allowed_groups": "legal", "allowed_users": {"id": "zoë"}, "doc_id": "doc-007"}: the filter allows, check denies; the reference allows, as the filter does
  Disagreeing hit: bob, doc-024 {"allowed_groups": "Eng", "doc_id": "doc-024"}: the filter allows, check denies; the reference allows, as the filter does
  Replay: `python benchmarks/paper/conformance_campaign.py run --targets cerbos --seed-list 0 --variants scalar-fields --examples 10 --stress-examples 3 --large-documents 150`

## cerbos-tenant

acceptance/policies/cerbos/document.yaml (tenant equality and sharing), loaded at startup.

Seeds 0-19; 10 corpora per seed for the default variant, 3 for the others; large corpora of up to 150 documents.

Image `ghcr.io/cerbos/cerbos:0.56.0`, id `sha256:9769be8555e0d7a5bf8da1d9b5bb6b64dfa7a8350a6a42d752e7dae7cbc6e584`, digests ['ghcr.io/cerbos/cerbos@sha256:540643bc67ba628011a150ad1d3370f285daa38995be5cd7a4be181da902bec1'].
Reported: `{"buildDate": "2026-09-30T06:22:34Z", "commit": "98604d71b79dafdc16ac57e4712fc435227e7c0f", "version": "0.56.0"}`.
Python packages: wardowl 2.1.0.

| Variant | Mode | Seeds | Pass | Violations | Refused | Errors | Subjects passing |
|---|---|---:|---:|---|---|---|---:|
| default | consistency | 20 | 20 | 0 | 0 | 0 | 240/240 |
| unicode-case | consistency | 20 | 20 | 0 | 0 | 0 | 160/160 |
| numeric-strings | consistency | 20 | 20 | 0 | 0 | 0 | 160/160 |
| many-groups | consistency | 20 | 20 | 0 | 0 | 0 | 60/60 |
| many-hits | consistency | 20 | 20 | 0 | 0 | 0 | 80/80 |
| long-ids | consistency | 20 | 20 | 0 | 0 | 0 | 160/160 |
| scalar-fields | consistency | 20 | 1 | 19 (filter-check-disagree 19) | 0 | 0 | 119/160 |

The first run of each kind of failure:

- scalar-fields (consistency), seed 0: **conformance-violation** filter-check-disagree. filter_for and check disagree (seed=0, example 0; rerun with the same seed to reproduce)
  Disagreeing hit: alice, doc-006 {"allowed_users": ["alice"], "doc_id": "doc-006", "tenant": ["northwind"]}: the filter allows, check denies; the reference allows, as the filter does
  Disagreeing hit: carol, doc-007 {"allowed_groups": "legal", "allowed_users": {"id": "zoë"}, "doc_id": "doc-007", "tenant": "acme"}: the filter allows, check denies; the reference allows, as the filter does
  Disagreeing hit: bob, doc-024 {"allowed_groups": "Eng", "doc_id": "doc-024", "tenant": "globex"}: the filter allows, check denies; the reference allows, as the filter does
  Replay: `python benchmarks/paper/conformance_campaign.py run --targets cerbos-tenant --seed-list 0 --variants scalar-fields --examples 10 --stress-examples 3 --large-documents 150`

## cedar

the metadata ACL policy of wardowl's tests, in process.

Seeds 0-19; 10 corpora per seed for the default variant, 3 for the others; large corpora of up to 150 documents.

Python packages: wardowl 2.1.0, cedarpy 4.12.2.

| Variant | Mode | Seeds | Pass | Violations | Refused | Errors | Subjects passing |
|---|---|---:|---:|---|---|---|---:|
| default | consistency | 20 | 20 | 0 | 0 | 0 | 240/240 |
| unicode-case | consistency | 20 | 20 | 0 | 0 | 0 | 160/160 |
| numeric-strings | consistency | 20 | 20 | 0 | 0 | 0 | 160/160 |
| many-groups | consistency | 20 | 20 | 0 | 0 | 0 | 60/60 |
| many-hits | consistency | 20 | 20 | 0 | 0 | 0 | 80/80 |
| long-ids | consistency | 20 | 20 | 0 | 0 | 0 | 160/160 |
| scalar-fields | consistency | 20 | 20 | 0 | 0 | 0 | 160/160 |

## cedar-tenant

acceptance/policies/cedar/documents.cedar (sharing, and a forbid across tenants), in process.

Seeds 0-19; 10 corpora per seed for the default variant, 3 for the others; large corpora of up to 150 documents.

Python packages: wardowl 2.1.0, cedarpy 4.12.2.

| Variant | Mode | Seeds | Pass | Violations | Refused | Errors | Subjects passing |
|---|---|---:|---:|---|---|---|---:|
| default | consistency | 20 | 20 | 0 | 0 | 0 | 240/240 |
| unicode-case | consistency | 20 | 20 | 0 | 0 | 0 | 160/160 |
| numeric-strings | consistency | 20 | 20 | 0 | 0 | 0 | 160/160 |
| many-groups | consistency | 20 | 20 | 0 | 0 | 0 | 60/60 |
| many-hits | consistency | 20 | 20 | 0 | 0 | 0 | 80/80 |
| long-ids | consistency | 20 | 20 | 0 | 0 | 0 | 160/160 |
| scalar-fields | consistency | 20 | 20 | 0 | 0 | 0 | 160/160 |

## casbin-tenant

acceptance/policies/casbin/model.conf (RBAC with a domain per tenant), a policy row per grant and a grouping row per membership, in process.

Seeds 0-19; 10 corpora per seed for the default variant, 3 for the others; large corpora of up to 150 documents.

Python packages: wardowl 2.1.0, casbin 1.43.0.

| Variant | Mode | Seeds | Pass | Violations | Refused | Errors | Subjects passing |
|---|---|---:|---:|---|---|---|---:|
| default | consistency | 20 | 20 | 0 | 0 | 0 | 240/240 |
| unicode-case | consistency | 20 | 20 | 0 | 0 | 0 | 160/160 |
| numeric-strings | consistency | 20 | 20 | 0 | 0 | 0 | 160/160 |
| many-groups | consistency | 20 | 20 | 0 | 0 | 0 | 60/60 |
| many-hits | consistency | 20 | 20 | 0 | 0 | 0 | 80/80 |
| long-ids | consistency | 20 | 20 | 0 | 0 | 0 | 160/160 |
| scalar-fields | consistency | 20 | 20 | 0 | 0 | 0 | 160/160 |

