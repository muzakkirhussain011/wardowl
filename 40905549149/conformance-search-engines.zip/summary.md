# Conformance campaign

wardowl 2.1.0 at commit `182bcbc53b9135c1c9bca4f0652a0f94ff2b9938`, workflow run 40905549149, Python 3.12.15: 3 targets, 540 runs.

Outcomes: **pass**, the kit found nothing; **conformance-violation**, the kit's first disagreement with the reference; **refused-ValueError**, wardowl refused the data or a filter; **error**, anything else. Engines are checked one subject at a time; a run takes its worst subject's outcome. Every run that did not pass is in its group's artifact, findings/<target>.txt, with the whole message. See benchmarks/paper/CONFORMANCE.md.

## Controls

- memory: not in these results.
- metadata-acl: not in these results.

## Violations

Wrong answers (leaks, filter and check disagreeing, altered metadata):

- none

Others:

- none

## Targets

Runs count one (seed, variant) each; sound-only retries of short exact answers are not counted here.

| Target | Family | Version | Status | Seeds | Runs | Pass | Violations | Refused | Errors |
|---|---|---|---|---:|---:|---:|---:|---:|---:|
| elasticsearch | store | `docker.elastic.co/elasticsearch/elasticsearch:9.5.5`; {"build_hash": "48acba663b09e70b115dd879329141506c377890", "lucene_version": "10.5.1"...(+20 characters) | complete | 20 | 180 | 160 | 0 | 0 | 20 |
| opensearch | store | `opensearchproject/opensearch:3.9.0`; {"build_hash": "4ee42a94e87f66fbf1e62a9871b1b87f91e02472", "distribution": "opensearch", "lucene_versi...(+33 characters) | complete | 20 | 180 | 160 | 0 | 0 | 20 |
| vespa | store | `vespaengine/vespa:8.763.13`; {"vespa": "8.763.13"} | complete | 20 | 180 | 180 | 0 | 0 | 0 |

## elasticsearch

an index for every corpus, as CI.

Seeds 0-19; 10 corpora per seed for the default variant, 3 for the others; large corpora of up to 150 documents.

Image `docker.elastic.co/elasticsearch/elasticsearch:9.5.5`, id `sha256:952a43cd5ab721f7032b2dfd4dcc86a76ba9a791b4c34a223292cf26a832e040`, digests ['docker.elastic.co/elasticsearch/elasticsearch@sha256:13b4a40bb095774f5fda635e45fd5677cc6a26565e42b24997b0c72b88e75984'].
Reported: `{"build_hash": "48acba663b09e70b115dd879329141506c377890", "lucene_version": "10.5.1", "number": "9.5.5"}`.
Python packages: wardowl 2.1.0, elasticsearch 9.5.1.

| Variant | Mode | Seeds | Pass | Violations | Refused | Errors | Filters refused |
|---|---|---:|---:|---|---|---|---:|
| default | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| large-corpus | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| deep-filters | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| wide-or | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| long-strings | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| huge-strings | exact | 20 | 0 | 0 | 0 | 20 (RuntimeError 16, BadRequestError 4) | 0 |
| unicode-case | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| numeric-strings | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| odd-fields | exact | 20 | 20 | 0 | 0 | 0 | 0 |

The first run of each kind of failure:

- huge-strings (exact), seed 0: **error** RuntimeError. bulk request failed for 'doc-000': {'type': 'document_parsing_exception', 'reason': "[1:72964] failed to parse field [wardowl_terms] of type [keyword] in document with id 'doc-000'. Preview of field's value: 'team\x1fs:xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx...(+3722 characters)
  Replay: `python benchmarks/paper/conformance_campaign.py run --targets elasticsearch --seed-list 0 --variants huge-strings --examples 10 --stress-examples 3 --large-documents 150`
- huge-strings (exact), seed 2: **error** BadRequestError. BadRequestError(400, 'x_content_parse_exception', '[1:498] [bool] failed to parse field [should]', [1:498] [bool] failed to parse field [filter])
  Replay: `python benchmarks/paper/conformance_campaign.py run --targets elasticsearch --seed-list 2 --variants huge-strings --examples 10 --stress-examples 3 --large-documents 150`

## opensearch

an index for every corpus, as CI.

Seeds 0-19; 10 corpora per seed for the default variant, 3 for the others; large corpora of up to 150 documents.

Image `opensearchproject/opensearch:3.9.0`, id `sha256:f546dde21473d6d15f4fe4e76e10a5da3fc09f6a0799721642344f9abab0737d`, digests ['opensearchproject/opensearch@sha256:3b55f6b6249cfdb92b52ee59adc8a266203ba9ef9f5d82544fad6f1af2f3609e'].
Reported: `{"build_hash": "4ee42a94e87f66fbf1e62a9871b1b87f91e02472", "distribution": "opensearch", "lucene_version": "10.5.1", "number": "3.9.0"}`.
Python packages: wardowl 2.1.0, opensearch-py 3.2.0.

| Variant | Mode | Seeds | Pass | Violations | Refused | Errors | Filters refused |
|---|---|---:|---:|---|---|---|---:|
| default | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| large-corpus | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| deep-filters | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| wide-or | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| long-strings | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| huge-strings | exact | 20 | 0 | 0 | 0 | 20 (RuntimeError 20) | 0 |
| unicode-case | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| numeric-strings | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| odd-fields | exact | 20 | 20 | 0 | 0 | 0 | 0 |

The first run of each kind of failure:

- huge-strings (exact), seed 0: **error** RuntimeError. bulk request failed for 'doc-000': {'type': 'illegal_argument_exception', 'reason': 'Document contains at least one immense term in field="wardowl_terms" (whose UTF8 encoding is longer than the max length 32766), all of which were skipped. Please correct the analyzer to not produce such terms. The p...(+382 characters)
  Replay: `python benchmarks/paper/conformance_campaign.py run --targets opensearch --seed-list 0 --variants huge-strings --examples 10 --stress-examples 3 --large-documents 150`

## vespa

the application in examples/vespa, exact search (approximate=False), as CI checks exactly.

Seeds 0-19; 10 corpora per seed for the default variant, 3 for the others; large corpora of up to 150 documents.

Image `vespaengine/vespa:8.763.13`, id `sha256:bf0656284b010ea46a277037c1d15b5c1b0c95fd425c6fa6aa95f3ea42112777`, digests ['vespaengine/vespa@sha256:a7694f0ddbece111ef9de25b5fbaf6ca7cc2540dcc40ec089a338fb13d295b50'].
Reported: `{"vespa": "8.763.13"}`.
Python packages: wardowl 2.1.0, httpx 0.28.1.

| Variant | Mode | Seeds | Pass | Violations | Refused | Errors | Filters refused |
|---|---|---:|---:|---|---|---|---:|
| default | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| large-corpus | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| deep-filters | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| wide-or | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| long-strings | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| huge-strings | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| unicode-case | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| numeric-strings | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| odd-fields | exact | 20 | 20 | 0 | 0 | 0 | 0 |

