# Conformance campaign

wardowl 2.1.0 at commit `182bcbc53b9135c1c9bca4f0652a0f94ff2b9938`, workflow run 40905549149, Python 3.12.15: 3 targets, 540 runs.

Outcomes: **pass**, the kit found nothing; **conformance-violation**, the kit's first disagreement with the reference; **refused-ValueError**, wardowl refused the data or a filter; **error**, anything else. Engines are checked one subject at a time; a run takes its worst subject's outcome. Every run that did not pass is in its group's artifact, findings/<target>.txt, with the whole message. See benchmarks/paper/CONFORMANCE.md.

## Controls

- memory: not in these results.
- metadata-acl: not in these results.

## Violations

Wrong answers (leaks, filter and check disagreeing, altered metadata):

- none

Others:

- none

## Targets

Runs count one (seed, variant) each; sound-only retries of short exact answers are not counted here.

| Target | Family | Version | Status | Seeds | Runs | Pass | Violations | Refused | Errors |
|---|---|---|---|---:|---:|---:|---:|---:|---:|
| pgvector | store | `pgvector/pgvector:pg17`; {"pgvector": "0.8.7", "postgresql": "PostgreSQL 17.11 (Debian 17.11-1.pgdg12+2) on x86_64-pc-linux-gnu, compiled b...(+49 characters) | complete | 20 | 180 | 180 | 0 | 0 | 0 |
| redis | store | `redis:8.10.2-alpine`; {"modules": {}, "redis": "8.10.2"} | complete | 20 | 180 | 180 | 0 | 0 | 0 |
| cassandra | store | `cassandra:5.0.9`; {"cassandra": "5.0.9"} | complete | 20 | 180 | 180 | 0 | 0 | 0 |

## pgvector

exact search (no HNSW index, iterative_scan=None), one table truncated for every corpus, as CI.

Seeds 0-19; 10 corpora per seed for the default variant, 3 for the others; large corpora of up to 150 documents.

Image `pgvector/pgvector:pg17`, id `sha256:151aa1c2e849e7828ed8aef2183ae15f692cbe887d2f28921d8b44b26e154d7e`, digests ['pgvector/pgvector@sha256:ac08538c6f8b9904c33c8224c5e5706dbe760aca29db1d096972b4052c22a75d'].
Reported: `{"pgvector": "0.8.7", "postgresql": "PostgreSQL 17.11 (Debian 17.11-1.pgdg12+2) on x86_64-pc-linux-gnu, compiled by gcc (Debian 12.2.0-14+deb12u1) 12.2.0, 64-bit"}`.
Python packages: wardowl 2.1.0, psycopg 3.3.6, psycopg-pool 3.3.3.

| Variant | Mode | Seeds | Pass | Violations | Refused | Errors | Filters refused |
|---|---|---:|---:|---|---|---|---:|
| default | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| large-corpus | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| deep-filters | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| wide-or | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| long-strings | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| huge-strings | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| unicode-case | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| numeric-strings | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| odd-fields | exact | 20 | 20 | 0 | 0 | 0 | 0 |

## redis

a FLAT (exact) index and prefix for every corpus, as CI checks exactly.

Seeds 0-19; 10 corpora per seed for the default variant, 3 for the others; large corpora of up to 150 documents.

Image `redis:8.10.2-alpine`, id `sha256:6cfed4c686145bcd5807ef3ac1d2bf3384503cb3da30b0d308b4f25eb50dc373`, digests ['redis@sha256:9f8d2d789b9a1d1e3f283f979aa9cbf393373806472e1ccd460e2f9c869b833b'].
Reported: `{"modules": {}, "redis": "8.10.2"}`.
Python packages: wardowl 2.1.0, redis 8.1.0.

| Variant | Mode | Seeds | Pass | Violations | Refused | Errors | Filters refused |
|---|---|---:|---:|---|---|---|---:|
| default | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| large-corpus | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| deep-filters | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| wide-or | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| long-strings | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| huge-strings | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| unicode-case | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| numeric-strings | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| odd-fields | exact | 20 | 20 | 0 | 0 | 0 | 0 |

## cassandra

sound-only (exact=False), as CI checks it: the jvector index is approximate; a table per corpus.

Seeds 0-19; 10 corpora per seed for the default variant, 3 for the others; large corpora of up to 150 documents.

Image `cassandra:5.0.9`, id `sha256:fc06f68aeda10243280761b99da9ec3e50cf96feed5395f5174dfabfb582a4dd`, digests ['cassandra@sha256:ae4cc2e4b62a5b2a2dd1645ba827cb50c589cc7531bcffe8b8b60ac3b1adc79d'].
Reported: `{"cassandra": "5.0.9"}`.
Python packages: wardowl 2.1.0, cassandra-driver 3.30.1.

| Variant | Mode | Seeds | Pass | Violations | Refused | Errors | Filters refused |
|---|---|---:|---:|---|---|---|---:|
| default | sound | 20 | 20 | 0 | 0 | 0 | 0 |
| large-corpus | sound | 20 | 20 | 0 | 0 | 0 | 0 |
| deep-filters | sound | 20 | 20 | 0 | 0 | 0 | 0 |
| wide-or | sound | 20 | 20 | 0 | 0 | 0 | 0 |
| long-strings | sound | 20 | 20 | 0 | 0 | 0 | 0 |
| huge-strings | sound | 20 | 20 | 0 | 0 | 0 | 0 |
| unicode-case | sound | 20 | 20 | 0 | 0 | 0 | 0 |
| numeric-strings | sound | 20 | 20 | 0 | 0 | 0 | 0 |
| odd-fields | sound | 20 | 20 | 0 | 0 | 0 | 0 |

