# Conformance campaign

wardowl 2.1.0 at commit `182bcbc53b9135c1c9bca4f0652a0f94ff2b9938`, workflow run 40905549149, Python 3.12.15: 29 targets, 4480 runs.

Outcomes: **pass**, the kit found nothing; **conformance-violation**, the kit's first disagreement with the reference; **refused-ValueError**, wardowl refused the data or a filter; **error**, anything else. Engines are checked one subject at a time; a run takes its worst subject's outcome. Every run that did not pass is in its group's artifact, findings/<target>.txt, with the whole message. See benchmarks/paper/CONFORMANCE.md.

## Controls

- memory: 180 of 180 runs pass.
- metadata-acl: 140 of 140 runs pass.

## Violations

Wrong answers (leaks, filter and check disagreeing, altered metadata):

- cerbos: filter-check-disagree in 20 runs (variants scalar-fields; seeds 0-19)
  - 235 disagreeing hits: the filter gives the reference answer for 235, check for 0
- cerbos-tenant: filter-check-disagree in 19 runs (variants scalar-fields; seeds 0-10, 12-19)
  - 45 disagreeing hits: the filter gives the reference answer for 45, check for 0

Others:

- none

## Targets

Runs count one (seed, variant) each; sound-only retries of short exact answers are not counted here.

| Target | Family | Version | Status | Seeds | Runs | Pass | Violations | Refused | Errors |
|---|---|---|---|---:|---:|---:|---:|---:|---:|
| memory | store |  | complete | 20 | 180 | 180 | 0 | 0 | 0 |
| pgvector | store | `pgvector/pgvector:pg17`; {"pgvector": "0.8.7", "postgresql": "PostgreSQL 17.11 (Debian 17.11-1.pgdg12+2) on x86_64-pc-linux-gnu, compiled b...(+49 characters) | complete | 20 | 180 | 180 | 0 | 0 | 0 |
| redis | store | `redis:8.10.2-alpine`; {"modules": {}, "redis": "8.10.2"} | complete | 20 | 180 | 180 | 0 | 0 | 0 |
| cassandra | store | `cassandra:5.0.9`; {"cassandra": "5.0.9"} | complete | 20 | 180 | 180 | 0 | 0 | 0 |
| elasticsearch | store | `docker.elastic.co/elasticsearch/elasticsearch:9.5.5`; {"build_hash": "48acba663b09e70b115dd879329141506c377890", "lucene_version": "10.5.1"...(+20 characters) | complete | 20 | 180 | 160 | 0 | 0 | 20 |
| opensearch | store | `opensearchproject/opensearch:3.9.0`; {"build_hash": "4ee42a94e87f66fbf1e62a9871b1b87f91e02472", "distribution": "opensearch", "lucene_versi...(+33 characters) | complete | 20 | 180 | 160 | 0 | 0 | 20 |
| vespa | store | `vespaengine/vespa:8.763.13`; {"vespa": "8.763.13"} | complete | 20 | 180 | 180 | 0 | 0 | 0 |
| qdrant | store | `qdrant/qdrant:v1.19.2`; {"qdrant": "1.19.2"} | complete | 20 | 180 | 160 | 0 | 0 | 20 |
| milvus | store | `milvusdb/milvus:v3.0.2`; {"milvus": "3.0.2"} | complete | 20 | 180 | 140 | 0 | 0 | 40 |
| weaviate | store | `cr.weaviate.io/semitechnologies/weaviate:1.39.12`; {"weaviate": "1.39.12"} | complete | 20 | 180 | 180 | 0 | 0 | 0 |
| mongodb | store | `mongodb/mongodb-atlas-local:8.0.30`; {"mongodb": "8.0.30"} | complete | 20 | 180 | 180 | 0 | 0 | 0 |
| chroma | store | chromadb 1.5.9 | complete | 20 | 180 | 140 | 0 | 0 | 40 |
| lancedb | store | lancedb 0.40.0, pyarrow 26.0.0 | complete | 20 | 180 | 180 | 0 | 0 | 0 |
| faiss | store | faiss-cpu 1.15.1, numpy 2.5.4 | complete | 20 | 180 | 180 | 0 | 0 | 0 |
| pinecone | store | httpx 0.28.1 | skipped: the PINECONE_API_KEY secret is not set | 0 | 0 | 0 | 0 | 0 | 0 |
| metadata-acl | engine |  | complete | 20 | 140 | 140 | 0 | 0 | 0 |
| opa | engine | {"opa": "Version: 1.21.2", "server": "1.21.2"} | complete | 20 | 140 | 140 | 0 | 0 | 0 |
| opa-tenant | engine | {"opa": "Version: 1.21.2", "server": "1.21.2"} | complete | 20 | 140 | 140 | 0 | 0 | 0 |
| openfga | engine | `openfga/openfga:v1.22.0` | complete | 20 | 140 | 21 | 0 | 119 | 0 |
| openfga-tenant | engine | `openfga/openfga:v1.22.0` | complete | 20 | 140 | 21 | 0 | 119 | 0 |
| spicedb | engine | `authzed/spicedb:v1.56.2` | complete | 20 | 140 | 16 | 0 | 124 | 0 |
| spicedb-tenant | engine | `authzed/spicedb:v1.56.2` | complete | 20 | 140 | 23 | 0 | 117 | 0 |
| cerbos | engine | `ghcr.io/cerbos/cerbos:0.56.0`; {"buildDate": "2026-09-30T06:22:34Z", "commit": "98604d71b79dafdc16ac57e4712fc435227e7c0f", "version": "0.56...(+4 characters) | complete | 20 | 140 | 120 | 20 | 0 | 0 |
| cerbos-tenant | engine | `ghcr.io/cerbos/cerbos:0.56.0`; {"buildDate": "2026-09-30T06:22:34Z", "commit": "98604d71b79dafdc16ac57e4712fc435227e7c0f", "version": "0.56...(+4 characters) | complete | 20 | 140 | 121 | 19 | 0 | 0 |
| keto | engine | `oryd/keto:v26.2.0`; {"keto": "v26.2.0"} | complete | 20 | 140 | 140 | 0 | 0 | 0 |
| cedar | engine | cedarpy 4.12.2 | complete | 20 | 140 | 140 | 0 | 0 | 0 |
| cedar-tenant | engine | cedarpy 4.12.2 | complete | 20 | 140 | 140 | 0 | 0 | 0 |
| casbin | engine | casbin 1.43.0 | complete | 20 | 140 | 140 | 0 | 0 | 0 |
| casbin-tenant | engine | casbin 1.43.0 | complete | 20 | 140 | 140 | 0 | 0 | 0 |

## memory

InMemoryBackend, the reference semantics: the positive control.

Seeds 0-19; 10 corpora per seed for the default variant, 3 for the others; large corpora of up to 150 documents.

Python packages: wardowl 2.1.0.

| Variant | Mode | Seeds | Pass | Violations | Refused | Errors | Filters refused |
|---|---|---:|---:|---|---|---|---:|
| default | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| large-corpus | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| deep-filters | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| wide-or | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| long-strings | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| huge-strings | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| unicode-case | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| numeric-strings | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| odd-fields | exact | 20 | 20 | 0 | 0 | 0 | 0 |

## pgvector

exact search (no HNSW index, iterative_scan=None), one table truncated for every corpus, as CI.

Seeds 0-19; 10 corpora per seed for the default variant, 3 for the others; large corpora of up to 150 documents.

Image `pgvector/pgvector:pg17`, id `sha256:151aa1c2e849e7828ed8aef2183ae15f692cbe887d2f28921d8b44b26e154d7e`, digests ['pgvector/pgvector@sha256:ac08538c6f8b9904c33c8224c5e5706dbe760aca29db1d096972b4052c22a75d'].
Reported: `{"pgvector": "0.8.7", "postgresql": "PostgreSQL 17.11 (Debian 17.11-1.pgdg12+2) on x86_64-pc-linux-gnu, compiled by gcc (Debian 12.2.0-14+deb12u1) 12.2.0, 64-bit"}`.
Python packages: wardowl 2.1.0, psycopg 3.3.6, psycopg-pool 3.3.3.

| Variant | Mode | Seeds | Pass | Violations | Refused | Errors | Filters refused |
|---|---|---:|---:|---|---|---|---:|
| default | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| large-corpus | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| deep-filters | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| wide-or | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| long-strings | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| huge-strings | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| unicode-case | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| numeric-strings | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| odd-fields | exact | 20 | 20 | 0 | 0 | 0 | 0 |

## redis

a FLAT (exact) index and prefix for every corpus, as CI checks exactly.

Seeds 0-19; 10 corpora per seed for the default variant, 3 for the others; large corpora of up to 150 documents.

Image `redis:8.10.2-alpine`, id `sha256:6cfed4c686145bcd5807ef3ac1d2bf3384503cb3da30b0d308b4f25eb50dc373`, digests ['redis@sha256:9f8d2d789b9a1d1e3f283f979aa9cbf393373806472e1ccd460e2f9c869b833b'].
Reported: `{"modules": {}, "redis": "8.10.2"}`.
Python packages: wardowl 2.1.0, redis 8.1.0.

| Variant | Mode | Seeds | Pass | Violations | Refused | Errors | Filters refused |
|---|---|---:|---:|---|---|---|---:|
| default | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| large-corpus | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| deep-filters | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| wide-or | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| long-strings | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| huge-strings | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| unicode-case | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| numeric-strings | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| odd-fields | exact | 20 | 20 | 0 | 0 | 0 | 0 |

## cassandra

sound-only (exact=False), as CI checks it: the jvector index is approximate; a table per corpus.

Seeds 0-19; 10 corpora per seed for the default variant, 3 for the others; large corpora of up to 150 documents.

Image `cassandra:5.0.9`, id `sha256:fc06f68aeda10243280761b99da9ec3e50cf96feed5395f5174dfabfb582a4dd`, digests ['cassandra@sha256:ae4cc2e4b62a5b2a2dd1645ba827cb50c589cc7531bcffe8b8b60ac3b1adc79d'].
Reported: `{"cassandra": "5.0.9"}`.
Python packages: wardowl 2.1.0, cassandra-driver 3.30.1.

| Variant | Mode | Seeds | Pass | Violations | Refused | Errors | Filters refused |
|---|---|---:|---:|---|---|---|---:|
| default | sound | 20 | 20 | 0 | 0 | 0 | 0 |
| large-corpus | sound | 20 | 20 | 0 | 0 | 0 | 0 |
| deep-filters | sound | 20 | 20 | 0 | 0 | 0 | 0 |
| wide-or | sound | 20 | 20 | 0 | 0 | 0 | 0 |
| long-strings | sound | 20 | 20 | 0 | 0 | 0 | 0 |
| huge-strings | sound | 20 | 20 | 0 | 0 | 0 | 0 |
| unicode-case | sound | 20 | 20 | 0 | 0 | 0 | 0 |
| numeric-strings | sound | 20 | 20 | 0 | 0 | 0 | 0 |
| odd-fields | sound | 20 | 20 | 0 | 0 | 0 | 0 |

## elasticsearch

an index for every corpus, as CI.

Seeds 0-19; 10 corpora per seed for the default variant, 3 for the others; large corpora of up to 150 documents.

Image `docker.elastic.co/elasticsearch/elasticsearch:9.5.5`, id `sha256:952a43cd5ab721f7032b2dfd4dcc86a76ba9a791b4c34a223292cf26a832e040`, digests ['docker.elastic.co/elasticsearch/elasticsearch@sha256:13b4a40bb095774f5fda635e45fd5677cc6a26565e42b24997b0c72b88e75984'].
Reported: `{"build_hash": "48acba663b09e70b115dd879329141506c377890", "lucene_version": "10.5.1", "number": "9.5.5"}`.
Python packages: wardowl 2.1.0, elasticsearch 9.5.1.

| Variant | Mode | Seeds | Pass | Violations | Refused | Errors | Filters refused |
|---|---|---:|---:|---|---|---|---:|
| default | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| large-corpus | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| deep-filters | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| wide-or | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| long-strings | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| huge-strings | exact | 20 | 0 | 0 | 0 | 20 (RuntimeError 16, BadRequestError 4) | 0 |
| unicode-case | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| numeric-strings | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| odd-fields | exact | 20 | 20 | 0 | 0 | 0 | 0 |

The first run of each kind of failure:

- huge-strings (exact), seed 0: **error** RuntimeError. bulk request failed for 'doc-000': {'type': 'document_parsing_exception', 'reason': "[1:72964] failed to parse field [wardowl_terms] of type [keyword] in document with id 'doc-000'. Preview of field's value: 'team\x1fs:xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx...(+3722 characters)
  Replay: `python benchmarks/paper/conformance_campaign.py run --targets elasticsearch --seed-list 0 --variants huge-strings --examples 10 --stress-examples 3 --large-documents 150`
- huge-strings (exact), seed 2: **error** BadRequestError. BadRequestError(400, 'x_content_parse_exception', '[1:498] [bool] failed to parse field [should]', [1:498] [bool] failed to parse field [filter])
  Replay: `python benchmarks/paper/conformance_campaign.py run --targets elasticsearch --seed-list 2 --variants huge-strings --examples 10 --stress-examples 3 --large-documents 150`

## opensearch

an index for every corpus, as CI.

Seeds 0-19; 10 corpora per seed for the default variant, 3 for the others; large corpora of up to 150 documents.

Image `opensearchproject/opensearch:3.9.0`, id `sha256:f546dde21473d6d15f4fe4e76e10a5da3fc09f6a0799721642344f9abab0737d`, digests ['opensearchproject/opensearch@sha256:3b55f6b6249cfdb92b52ee59adc8a266203ba9ef9f5d82544fad6f1af2f3609e'].
Reported: `{"build_hash": "4ee42a94e87f66fbf1e62a9871b1b87f91e02472", "distribution": "opensearch", "lucene_version": "10.5.1", "number": "3.9.0"}`.
Python packages: wardowl 2.1.0, opensearch-py 3.2.0.

| Variant | Mode | Seeds | Pass | Violations | Refused | Errors | Filters refused |
|---|---|---:|---:|---|---|---|---:|
| default | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| large-corpus | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| deep-filters | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| wide-or | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| long-strings | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| huge-strings | exact | 20 | 0 | 0 | 0 | 20 (RuntimeError 20) | 0 |
| unicode-case | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| numeric-strings | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| odd-fields | exact | 20 | 20 | 0 | 0 | 0 | 0 |

The first run of each kind of failure:

- huge-strings (exact), seed 0: **error** RuntimeError. bulk request failed for 'doc-000': {'type': 'illegal_argument_exception', 'reason': 'Document contains at least one immense term in field="wardowl_terms" (whose UTF8 encoding is longer than the max length 32766), all of which were skipped. Please correct the analyzer to not produce such terms. The p...(+382 characters)
  Replay: `python benchmarks/paper/conformance_campaign.py run --targets opensearch --seed-list 0 --variants huge-strings --examples 10 --stress-examples 3 --large-documents 150`

## vespa

the application in examples/vespa, exact search (approximate=False), as CI checks exactly.

Seeds 0-19; 10 corpora per seed for the default variant, 3 for the others; large corpora of up to 150 documents.

Image `vespaengine/vespa:8.763.13`, id `sha256:bf0656284b010ea46a277037c1d15b5c1b0c95fd425c6fa6aa95f3ea42112777`, digests ['vespaengine/vespa@sha256:a7694f0ddbece111ef9de25b5fbaf6ca7cc2540dcc40ec089a338fb13d295b50'].
Reported: `{"vespa": "8.763.13"}`.
Python packages: wardowl 2.1.0, httpx 0.28.1.

| Variant | Mode | Seeds | Pass | Violations | Refused | Errors | Filters refused |
|---|---|---:|---:|---|---|---|---:|
| default | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| large-corpus | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| deep-filters | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| wide-or | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| long-strings | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| huge-strings | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| unicode-case | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| numeric-strings | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| odd-fields | exact | 20 | 20 | 0 | 0 | 0 | 0 |

## qdrant

the server, a collection for every corpus, as CI.

Seeds 0-19; 10 corpora per seed for the default variant, 3 for the others; large corpora of up to 150 documents.

Image `qdrant/qdrant:v1.19.2`, id `sha256:e37a07939a01ae09875d5cd58cd05a5e7c393151fce5e0a524c083835570e8e7`, digests ['qdrant/qdrant@sha256:b7b0444c4c351c970b98e90a6f89c2ee4287c65b44e52b4cb503fa5b2aa927ad'].
Reported: `{"qdrant": "1.19.2"}`.
Python packages: wardowl 2.1.0, qdrant-client 1.19.1.

| Variant | Mode | Seeds | Pass | Violations | Refused | Errors | Filters refused |
|---|---|---:|---:|---|---|---|---:|
| default | exact | 20 | 20 | 0 | 0 | 0 | 440 |
| large-corpus | exact | 20 | 20 | 0 | 0 | 0 | 197 |
| deep-filters | exact | 20 | 20 | 0 | 0 | 0 | 340 |
| wide-or | exact | 20 | 20 | 0 | 0 | 0 | 59 |
| long-strings | exact | 20 | 20 | 0 | 0 | 0 | 122 |
| huge-strings | exact | 20 | 20 | 0 | 0 | 0 | 133 |
| unicode-case | exact | 20 | 20 | 0 | 0 | 0 | 111 |
| numeric-strings | exact | 20 | 20 | 0 | 0 | 0 | 125 |
| odd-fields | exact | 20 | 0 | 0 | 0 | 20 (UnexpectedResponse 20) | 47 |

The first run of each kind of failure:

- odd-fields (exact), seed 0: **error** UnexpectedResponse. Unexpected Response: 400 (Bad Request)
  Replay: `python benchmarks/paper/conformance_campaign.py run --targets qdrant --seed-list 0 --variants odd-fields --examples 10 --stress-examples 3 --large-documents 150`

## milvus

standalone, a collection for every corpus, as CI.

Seeds 0-19; 10 corpora per seed for the default variant, 3 for the others; large corpora of up to 150 documents.

Image `milvusdb/milvus:v3.0.2`, id `sha256:544c055ed25a2d22e4d3366c7c6b6f8b2240494eee605994bd1988437fa27ac8`, digests ['milvusdb/milvus@sha256:5f13bf88e110a517911c3e6dd8172454e90042c21e606a868084615a4302c8a0'].
Reported: `{"milvus": "3.0.2"}`.
Python packages: wardowl 2.1.0, pymilvus 3.0.2.

| Variant | Mode | Seeds | Pass | Violations | Refused | Errors | Filters refused |
|---|---|---:|---:|---|---|---|---:|
| default | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| large-corpus | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| deep-filters | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| wide-or | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| long-strings | exact | 20 | 0 | 0 | 0 | 20 (MilvusException 20) | 0 |
| huge-strings | exact | 20 | 0 | 0 | 0 | 20 (MilvusException 20) | 0 |
| unicode-case | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| numeric-strings | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| odd-fields | exact | 20 | 20 | 0 | 0 | 0 | 0 |

The first run of each kind of failure:

- long-strings (exact), seed 0: **error** MilvusException. <MilvusException: (code=1100, message=length of Array array field "wardowl_terms" exceeds max length, row number: 0, array index: 1, length: 8199, max length: 1024: invalid parameter)>
  Replay: `python benchmarks/paper/conformance_campaign.py run --targets milvus --seed-list 0 --variants long-strings --examples 10 --stress-examples 3 --large-documents 150`
- huge-strings (exact), seed 0: **error** MilvusException. <MilvusException: (code=1100, message=the length (72841) of json field (metadata) exceeds max length (65536): invalid parameter[expected=valid length json string][actual=length exceeds max length])>
  Replay: `python benchmarks/paper/conformance_campaign.py run --targets milvus --seed-list 0 --variants huge-strings --examples 10 --stress-examples 3 --large-documents 150`

## weaviate

vectors from the client, a collection for every corpus, as CI.

Seeds 0-19; 10 corpora per seed for the default variant, 3 for the others; large corpora of up to 150 documents.

Image `cr.weaviate.io/semitechnologies/weaviate:1.39.12`, id `sha256:21f12a8c5e76a5a17d8df4a0d7b5ef382e559987355201b9a8869893da66d082`, digests ['cr.weaviate.io/semitechnologies/weaviate@sha256:2bc7ebd9aabc34f9d99602c42ffa274cd086110694895197893331f95462c671'].
Reported: `{"weaviate": "1.39.12"}`.
Python packages: wardowl 2.1.0, weaviate-client 4.23.1.

| Variant | Mode | Seeds | Pass | Violations | Refused | Errors | Filters refused |
|---|---|---:|---:|---|---|---|---:|
| default | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| large-corpus | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| deep-filters | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| wide-or | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| long-strings | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| huge-strings | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| unicode-case | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| numeric-strings | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| odd-fields | exact | 20 | 20 | 0 | 0 | 0 | 0 |

## mongodb

a local Atlas deployment, one collection and vector index for every corpus in turn, as CI.

Seeds 0-19; 10 corpora per seed for the default variant, 3 for the others; large corpora of up to 150 documents.

Image `mongodb/mongodb-atlas-local:8.0.30`, id `sha256:f2432378f9951befd3e0e3bffe51384204ecdd1ce614d53a249662a23fdd959a`, digests ['mongodb/mongodb-atlas-local@sha256:6d36b4421491ab115291361385c37484a3750ae46c9e35fdfe4123841979b044'].
Reported: `{"mongodb": "8.0.30"}`.
Python packages: wardowl 2.1.0, pymongo 4.19.0.

| Variant | Mode | Seeds | Pass | Violations | Refused | Errors | Filters refused |
|---|---|---:|---:|---|---|---|---:|
| default | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| large-corpus | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| deep-filters | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| wide-or | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| long-strings | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| huge-strings | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| unicode-case | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| numeric-strings | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| odd-fields | exact | 20 | 20 | 0 | 0 | 0 | 0 |

## chroma

embedded (EphemeralClient), a collection for every corpus, as CI.

Seeds 0-19; 10 corpora per seed for the default variant, 3 for the others; large corpora of up to 150 documents.

Python packages: wardowl 2.1.0, chromadb 1.5.9.

| Variant | Mode | Seeds | Pass | Violations | Refused | Errors | Filters refused |
|---|---|---:|---:|---|---|---|---:|
| default | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| large-corpus | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| deep-filters | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| wide-or | exact | 20 | 0 | 0 | 0 | 20 (InternalError 20) | 0 |
| long-strings | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| huge-strings | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| unicode-case | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| numeric-strings | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| odd-fields | exact | 20 | 0 | 0 | 0 | 20 (InvalidArgumentError 20) | 0 |

The first run of each kind of failure:

- wide-or (exact), seed 0: **error** InternalError. Error executing plan: Internal error: error returned from database: (code: 1) Expression tree is too large (maximum depth 1000)
  Replay: `python benchmarks/paper/conformance_campaign.py run --targets chroma --seed-list 0 --variants wide-or --examples 10 --stress-examples 3 --large-documents 150`
- odd-fields (exact), seed 0: **error** InvalidArgumentError. Validation error: metadatas: Invalid metadata at index 3
  Replay: `python benchmarks/paper/conformance_campaign.py run --targets chroma --seed-list 0 --variants odd-fields --examples 10 --stress-examples 3 --large-documents 150`

## lancedb

embedded, in a temporary directory, a table for every corpus, as CI.

Seeds 0-19; 10 corpora per seed for the default variant, 3 for the others; large corpora of up to 150 documents.

Python packages: wardowl 2.1.0, lancedb 0.40.0, pyarrow 26.0.0.

| Variant | Mode | Seeds | Pass | Violations | Refused | Errors | Filters refused |
|---|---|---:|---:|---|---|---|---:|
| default | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| large-corpus | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| deep-filters | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| wide-or | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| long-strings | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| huge-strings | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| unicode-case | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| numeric-strings | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| odd-fields | exact | 20 | 20 | 0 | 0 | 0 | 0 |

## faiss

in process, a new flat index for every corpus, as CI.

Seeds 0-19; 10 corpora per seed for the default variant, 3 for the others; large corpora of up to 150 documents.

Python packages: wardowl 2.1.0, faiss-cpu 1.15.1, numpy 2.5.4.

| Variant | Mode | Seeds | Pass | Violations | Refused | Errors | Filters refused |
|---|---|---:|---:|---|---|---|---:|
| default | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| large-corpus | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| deep-filters | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| wide-or | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| long-strings | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| huge-strings | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| unicode-case | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| numeric-strings | exact | 20 | 20 | 0 | 0 | 0 | 0 |
| odd-fields | exact | 20 | 20 | 0 | 0 | 0 | 0 |

## pinecone

the service: CI's index wardowl-ci, a namespace for every corpus, writes waited for up to 60 s.

Seeds 0-19; 4 corpora per seed for the default variant, 2 for the others; large corpora of up to 40 documents.

Python packages: wardowl 2.1.0, httpx 0.28.1.

No runs.

## metadata-acl

MetadataACLAuthorizer, in process: the positive control.

Seeds 0-19; 10 corpora per seed for the default variant, 3 for the others; large corpora of up to 150 documents.

Python packages: wardowl 2.1.0.

| Variant | Mode | Seeds | Pass | Violations | Refused | Errors | Subjects passing |
|---|---|---:|---:|---|---|---|---:|
| default | consistency | 20 | 20 | 0 | 0 | 0 | 240/240 |
| unicode-case | consistency | 20 | 20 | 0 | 0 | 0 | 160/160 |
| numeric-strings | consistency | 20 | 20 | 0 | 0 | 0 | 160/160 |
| many-groups | consistency | 20 | 20 | 0 | 0 | 0 | 60/60 |
| many-hits | consistency | 20 | 20 | 0 | 0 | 0 | 80/80 |
| long-ids | consistency | 20 | 20 | 0 | 0 | 0 | 160/160 |
| scalar-fields | consistency | 20 | 20 | 0 | 0 | 0 | 160/160 |

## opa

examples/opa/wardowl.rego, loaded at startup as CI loads it, with filter_path wardowl/filter.

Seeds 0-19; 10 corpora per seed for the default variant, 3 for the others; large corpora of up to 150 documents.

Reported: `{"opa": "Version: 1.21.2", "server": "1.21.2"}`.
Python packages: wardowl 2.1.0.

| Variant | Mode | Seeds | Pass | Violations | Refused | Errors | Subjects passing |
|---|---|---:|---:|---|---|---|---:|
| default | consistency | 20 | 20 | 0 | 0 | 0 | 240/240 |
| unicode-case | consistency | 20 | 20 | 0 | 0 | 0 | 160/160 |
| numeric-strings | consistency | 20 | 20 | 0 | 0 | 0 | 160/160 |
| many-groups | consistency | 20 | 20 | 0 | 0 | 0 | 60/60 |
| many-hits | consistency | 20 | 20 | 0 | 0 | 0 | 80/80 |
| long-ids | consistency | 20 | 20 | 0 | 0 | 0 | 160/160 |
| scalar-fields | consistency | 20 | 20 | 0 | 0 | 0 | 160/160 |

## opa-tenant

acceptance/policies/opa/documents.rego, uploaded under a package of the run's own, with the sharing of every chunk pushed as OPA data; its filter_path returns an In on doc_id.

Seeds 0-19; 10 corpora per seed for the default variant, 3 for the others; large corpora of up to 150 documents.

Reported: `{"opa": "Version: 1.21.2", "server": "1.21.2"}`.
Python packages: wardowl 2.1.0.

| Variant | Mode | Seeds | Pass | Violations | Refused | Errors | Subjects passing |
|---|---|---:|---:|---|---|---|---:|
| default | consistency | 20 | 20 | 0 | 0 | 0 | 240/240 |
| unicode-case | consistency | 20 | 20 | 0 | 0 | 0 | 160/160 |
| numeric-strings | consistency | 20 | 20 | 0 | 0 | 0 | 160/160 |
| many-groups | consistency | 20 | 20 | 0 | 0 | 0 | 60/60 |
| many-hits | consistency | 20 | 20 | 0 | 0 | 0 | 80/80 |
| long-ids | consistency | 20 | 20 | 0 | 0 | 0 | 160/160 |
| scalar-fields | consistency | 20 | 20 | 0 | 0 | 0 | 160/160 |

## openfga

the model of wardowl's tests (user, user:*, group#member viewers), a store per run, a tuple per grant in the chunks' ACLs; groups as contextual tuples; HIGHER_CONSISTENCY.

Seeds 0-19; 10 corpora per seed for the default variant, 3 for the others; large corpora of up to 150 documents.

Image `openfga/openfga:v1.22.0`, id `sha256:6da24ff138aff7a2fe5273819516d52ca2103086d909338531e13cb3b7c9b943`, digests ['openfga/openfga@sha256:9cf9a20af32a40434cd3a788c429879439ee9ea9abf65c9c200ee17cd43f769e'].
Python packages: wardowl 2.1.0.

| Variant | Mode | Seeds | Pass | Violations | Refused | Errors | Subjects passing |
|---|---|---:|---:|---|---|---|---:|
| default | consistency | 20 | 2 | 0 | 18 (UnsupportedSubject 18) | 0 | 198/240 |
| unicode-case | consistency | 20 | 4 | 0 | 16 (UnsupportedSubject 16) | 0 | 129/160 |
| numeric-strings | consistency | 20 | 3 | 0 | 17 (UnsupportedSubject 17) | 0 | 125/160 |
| many-groups | consistency | 20 | 0 | 0 | 20 (UnsupportedSubject 20) | 0 | 0/60 |
| many-hits | consistency | 20 | 8 | 0 | 12 (UnsupportedSubject 12) | 0 | 68/80 |
| long-ids | consistency | 20 | 0 | 0 | 20 (UnsupportedSubject 20) | 0 | 48/160 |
| scalar-fields | consistency | 20 | 4 | 0 | 16 (UnsupportedSubject 16) | 0 | 134/160 |

The first run of each kind of failure:

- default (consistency), seed 0: **refused-ValueError** UnsupportedSubject. subject 'alice' is in 301 groups, which cannot be sent to OpenFGA: it takes at most 100 contextual tuples per check; store the memberships in OpenFGA and set contextual_groups=False
  Replay: `python benchmarks/paper/conformance_campaign.py run --targets openfga --seed-list 0 --variants default --examples 10 --stress-examples 3 --large-documents 150`
- unicode-case (consistency), seed 0: **refused-ValueError** UnsupportedSubject. subject 'Bob' is in 302 groups, which cannot be sent to OpenFGA: it takes at most 100 contextual tuples per check; store the memberships in OpenFGA and set contextual_groups=False
  Replay: `python benchmarks/paper/conformance_campaign.py run --targets openfga --seed-list 0 --variants unicode-case --examples 10 --stress-examples 3 --large-documents 150`
- numeric-strings (consistency), seed 0: **refused-ValueError** UnsupportedSubject. subject '7.0' is in 303 groups, which cannot be sent to OpenFGA: it takes at most 100 contextual tuples per check; store the memberships in OpenFGA and set contextual_groups=False
  Replay: `python benchmarks/paper/conformance_campaign.py run --targets openfga --seed-list 0 --variants numeric-strings --examples 10 --stress-examples 3 --large-documents 150`
- many-groups (consistency), seed 0: **refused-ValueError** UnsupportedSubject. subject 'Bob' is in 1,002 groups, which cannot be sent to OpenFGA: it takes at most 100 contextual tuples per check; store the memberships in OpenFGA and set contextual_groups=False
  Replay: `python benchmarks/paper/conformance_campaign.py run --targets openfga --seed-list 0 --variants many-groups --examples 10 --stress-examples 3 --large-documents 150`
- many-hits (consistency), seed 0: **refused-ValueError** UnsupportedSubject. subject 'dave' is in 301 groups, which cannot be sent to OpenFGA: it takes at most 100 contextual tuples per check; store the memberships in OpenFGA and set contextual_groups=False
  Replay: `python benchmarks/paper/conformance_campaign.py run --targets openfga --seed-list 0 --variants many-hits --examples 10 --stress-examples 3 --large-documents 150`
- long-ids (consistency), seed 0: **refused-ValueError** UnsupportedSubject. group 'gggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggg'... (256 characters) cannot be sent to OpenFGA: group:<group> is longer than 256 characters
  Replay: `python benchmarks/paper/conformance_campaign.py run --targets openfga --seed-list 0 --variants long-ids --examples 10 --stress-examples 3 --large-documents 150`
- scalar-fields (consistency), seed 0: **refused-ValueError** UnsupportedSubject. subject 'alice' is in 300 groups, which cannot be sent to OpenFGA: it takes at most 100 contextual tuples per check; store the memberships in OpenFGA and set contextual_groups=False
  Replay: `python benchmarks/paper/conformance_campaign.py run --targets openfga --seed-list 0 --variants scalar-fields --examples 10 --stress-examples 3 --large-documents 150`

## openfga-tenant

acceptance/policies/openfga/model.json (a tenant intersection), a store per run, tuples for each subject's tenant and each chunk's tenant and readers; groups as contextual tuples; HIGHER_CONSISTENCY.

Seeds 0-19; 10 corpora per seed for the default variant, 3 for the others; large corpora of up to 150 documents.

Image `openfga/openfga:v1.22.0`, id `sha256:6da24ff138aff7a2fe5273819516d52ca2103086d909338531e13cb3b7c9b943`, digests ['openfga/openfga@sha256:9cf9a20af32a40434cd3a788c429879439ee9ea9abf65c9c200ee17cd43f769e'].
Python packages: wardowl 2.1.0.

| Variant | Mode | Seeds | Pass | Violations | Refused | Errors | Subjects passing |
|---|---|---:|---:|---|---|---|---:|
| default | consistency | 20 | 2 | 0 | 18 (UnsupportedSubject 18) | 0 | 198/240 |
| unicode-case | consistency | 20 | 4 | 0 | 16 (UnsupportedSubject 16) | 0 | 129/160 |
| numeric-strings | consistency | 20 | 3 | 0 | 17 (UnsupportedSubject 17) | 0 | 125/160 |
| many-groups | consistency | 20 | 0 | 0 | 20 (UnsupportedSubject 20) | 0 | 0/60 |
| many-hits | consistency | 20 | 8 | 0 | 12 (UnsupportedSubject 12) | 0 | 68/80 |
| long-ids | consistency | 20 | 0 | 0 | 20 (UnsupportedSubject 20) | 0 | 48/160 |
| scalar-fields | consistency | 20 | 4 | 0 | 16 (UnsupportedSubject 16) | 0 | 134/160 |

The first run of each kind of failure:

- default (consistency), seed 0: **refused-ValueError** UnsupportedSubject. subject 'alice' is in 301 groups, which cannot be sent to OpenFGA: it takes at most 100 contextual tuples per check; store the memberships in OpenFGA and set contextual_groups=False
  Replay: `python benchmarks/paper/conformance_campaign.py run --targets openfga-tenant --seed-list 0 --variants default --examples 10 --stress-examples 3 --large-documents 150`
- unicode-case (consistency), seed 0: **refused-ValueError** UnsupportedSubject. subject 'Bob' is in 302 groups, which cannot be sent to OpenFGA: it takes at most 100 contextual tuples per check; store the memberships in OpenFGA and set contextual_groups=False
  Replay: `python benchmarks/paper/conformance_campaign.py run --targets openfga-tenant --seed-list 0 --variants unicode-case --examples 10 --stress-examples 3 --large-documents 150`
- numeric-strings (consistency), seed 0: **refused-ValueError** UnsupportedSubject. subject '7.0' is in 303 groups, which cannot be sent to OpenFGA: it takes at most 100 contextual tuples per check; store the memberships in OpenFGA and set contextual_groups=False
  Replay: `python benchmarks/paper/conformance_campaign.py run --targets openfga-tenant --seed-list 0 --variants numeric-strings --examples 10 --stress-examples 3 --large-documents 150`
- many-groups (consistency), seed 0: **refused-ValueError** UnsupportedSubject. subject 'Bob' is in 1,002 groups, which cannot be sent to OpenFGA: it takes at most 100 contextual tuples per check; store the memberships in OpenFGA and set contextual_groups=False
  Replay: `python benchmarks/paper/conformance_campaign.py run --targets openfga-tenant --seed-list 0 --variants many-groups --examples 10 --stress-examples 3 --large-documents 150`
- many-hits (consistency), seed 0: **refused-ValueError** UnsupportedSubject. subject 'dave' is in 301 groups, which cannot be sent to OpenFGA: it takes at most 100 contextual tuples per check; store the memberships in OpenFGA and set contextual_groups=False
  Replay: `python benchmarks/paper/conformance_campaign.py run --targets openfga-tenant --seed-list 0 --variants many-hits --examples 10 --stress-examples 3 --large-documents 150`
- long-ids (consistency), seed 0: **refused-ValueError** UnsupportedSubject. group 'gggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggg'... (256 characters) cannot be sent to OpenFGA: group:<group> is longer than 256 characters
  Replay: `python benchmarks/paper/conformance_campaign.py run --targets openfga-tenant --seed-list 0 --variants long-ids --examples 10 --stress-examples 3 --large-documents 150`
- scalar-fields (consistency), seed 0: **refused-ValueError** UnsupportedSubject. subject 'alice' is in 300 groups, which cannot be sent to OpenFGA: it takes at most 100 contextual tuples per check; store the memberships in OpenFGA and set contextual_groups=False
  Replay: `python benchmarks/paper/conformance_campaign.py run --targets openfga-tenant --seed-list 0 --variants scalar-fields --examples 10 --stress-examples 3 --large-documents 150`

## spicedb

the schema of wardowl's tests (user, user:*, group#member viewers), groups checked as subject sets (group_subjects=True), fully consistent.

Seeds 0-19; 10 corpora per seed for the default variant, 3 for the others; large corpora of up to 150 documents.

Image `authzed/spicedb:v1.56.2`, id `sha256:3bad3b99cc5d01cbe99a8974921cdef45625f5b544c343432549485bb182e811`, digests ['authzed/spicedb@sha256:aa96009a0477f8a759149823407d47ad16d1a74390bae3102b3b0b7143502764'].
Python packages: wardowl 2.1.0.

| Variant | Mode | Seeds | Pass | Violations | Refused | Errors | Subjects passing |
|---|---|---:|---:|---|---|---|---:|
| default | consistency | 20 | 1 | 0 | 19 (UnsupportedSubject 19) | 0 | 165/240 |
| unicode-case | consistency | 20 | 0 | 0 | 20 (UnsupportedSubject 20) | 0 | 41/160 |
| numeric-strings | consistency | 20 | 0 | 0 | 20 (UnsupportedSubject 20) | 0 | 52/160 |
| many-groups | consistency | 20 | 5 | 0 | 15 (UnsupportedSubject 15) | 0 | 35/60 |
| many-hits | consistency | 20 | 5 | 0 | 15 (UnsupportedSubject 15) | 0 | 56/80 |
| long-ids | consistency | 20 | 3 | 0 | 17 (UnsupportedSubject 17) | 0 | 122/160 |
| scalar-fields | consistency | 20 | 2 | 0 | 18 (UnsupportedSubject 18) | 0 | 118/160 |

The first run of each kind of failure:

- default (consistency), seed 0: **refused-ValueError** UnsupportedSubject. subject id 'zoë' cannot be sent to SpiceDB: object ids are 1 to 1024 letters, digits and /_\|-=+
  Replay: `python benchmarks/paper/conformance_campaign.py run --targets spicedb --seed-list 0 --variants default --examples 10 --stress-examples 3 --large-documents 150`
- unicode-case (consistency), seed 0: **refused-ValueError** UnsupportedSubject. group 'ß' cannot be sent to SpiceDB: object ids are 1 to 1024 letters, digits and /_\|-=+
  Replay: `python benchmarks/paper/conformance_campaign.py run --targets spicedb --seed-list 0 --variants unicode-case --examples 10 --stress-examples 3 --large-documents 150`
- numeric-strings (consistency), seed 0: **refused-ValueError** UnsupportedSubject. subject id '7.0' cannot be sent to SpiceDB: object ids are 1 to 1024 letters, digits and /_\|-=+
  Replay: `python benchmarks/paper/conformance_campaign.py run --targets spicedb --seed-list 0 --variants numeric-strings --examples 10 --stress-examples 3 --large-documents 150`
- many-groups (consistency), seed 0: **refused-ValueError** UnsupportedSubject. subject id 'zoë' cannot be sent to SpiceDB: object ids are 1 to 1024 letters, digits and /_\|-=+
  Replay: `python benchmarks/paper/conformance_campaign.py run --targets spicedb --seed-list 0 --variants many-groups --examples 10 --stress-examples 3 --large-documents 150`
- many-hits (consistency), seed 1: **refused-ValueError** UnsupportedSubject. subject id 'zoë' cannot be sent to SpiceDB: object ids are 1 to 1024 letters, digits and /_\|-=+
  Replay: `python benchmarks/paper/conformance_campaign.py run --targets spicedb --seed-list 1 --variants many-hits --examples 10 --stress-examples 3 --large-documents 150`
- long-ids (consistency), seed 0: **refused-ValueError** UnsupportedSubject. group 'gggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggg'... (4,096 characters) cannot be sent to SpiceDB: object ids are 1 to 1024 letters, digits and /_\|-=+
  Replay: `python benchmarks/paper/conformance_campaign.py run --targets spicedb --seed-list 0 --variants long-ids --examples 10 --stress-examples 3 --large-documents 150`
- scalar-fields (consistency), seed 1: **refused-ValueError** UnsupportedSubject. subject id 'zoë' cannot be sent to SpiceDB: object ids are 1 to 1024 letters, digits and /_\|-=+
  Replay: `python benchmarks/paper/conformance_campaign.py run --targets spicedb --seed-list 1 --variants scalar-fields --examples 10 --stress-examples 3 --large-documents 150`

## spicedb-tenant

acceptance/policies/spicedb/schema.zed (view = reader & tenant->member), memberships stored in SpiceDB, group_subjects=False, fully consistent.

Seeds 0-19; 10 corpora per seed for the default variant, 3 for the others; large corpora of up to 150 documents.

Image `authzed/spicedb:v1.56.2`, id `sha256:3bad3b99cc5d01cbe99a8974921cdef45625f5b544c343432549485bb182e811`, digests ['authzed/spicedb@sha256:aa96009a0477f8a759149823407d47ad16d1a74390bae3102b3b0b7143502764'].
Python packages: wardowl 2.1.0.

| Variant | Mode | Seeds | Pass | Violations | Refused | Errors | Subjects passing |
|---|---|---:|---:|---|---|---|---:|
| default | consistency | 20 | 1 | 0 | 19 (UnsupportedSubject 19) | 0 | 165/240 |
| unicode-case | consistency | 20 | 0 | 0 | 20 (UnsupportedSubject 20) | 0 | 84/160 |
| numeric-strings | consistency | 20 | 0 | 0 | 20 (UnsupportedSubject 20) | 0 | 93/160 |
| many-groups | consistency | 20 | 5 | 0 | 15 (UnsupportedSubject 15) | 0 | 35/60 |
| many-hits | consistency | 20 | 5 | 0 | 15 (UnsupportedSubject 15) | 0 | 56/80 |
| long-ids | consistency | 20 | 10 | 0 | 10 (UnsupportedSubject 10) | 0 | 143/160 |
| scalar-fields | consistency | 20 | 2 | 0 | 18 (UnsupportedSubject 18) | 0 | 118/160 |

The first run of each kind of failure:

- default (consistency), seed 0: **refused-ValueError** UnsupportedSubject. subject id 'zoë' cannot be sent to SpiceDB: object ids are 1 to 1024 letters, digits and /_\|-=+
  Replay: `python benchmarks/paper/conformance_campaign.py run --targets spicedb-tenant --seed-list 0 --variants default --examples 10 --stress-examples 3 --large-documents 150`
- unicode-case (consistency), seed 0: **refused-ValueError** UnsupportedSubject. subject id 'zoë' cannot be sent to SpiceDB: object ids are 1 to 1024 letters, digits and /_\|-=+
  Replay: `python benchmarks/paper/conformance_campaign.py run --targets spicedb-tenant --seed-list 0 --variants unicode-case --examples 10 --stress-examples 3 --large-documents 150`
- numeric-strings (consistency), seed 0: **refused-ValueError** UnsupportedSubject. subject id '7.0' cannot be sent to SpiceDB: object ids are 1 to 1024 letters, digits and /_\|-=+
  Replay: `python benchmarks/paper/conformance_campaign.py run --targets spicedb-tenant --seed-list 0 --variants numeric-strings --examples 10 --stress-examples 3 --large-documents 150`
- many-groups (consistency), seed 0: **refused-ValueError** UnsupportedSubject. subject id 'zoë' cannot be sent to SpiceDB: object ids are 1 to 1024 letters, digits and /_\|-=+
  Replay: `python benchmarks/paper/conformance_campaign.py run --targets spicedb-tenant --seed-list 0 --variants many-groups --examples 10 --stress-examples 3 --large-documents 150`
- many-hits (consistency), seed 1: **refused-ValueError** UnsupportedSubject. subject id 'zoë' cannot be sent to SpiceDB: object ids are 1 to 1024 letters, digits and /_\|-=+
  Replay: `python benchmarks/paper/conformance_campaign.py run --targets spicedb-tenant --seed-list 1 --variants many-hits --examples 10 --stress-examples 3 --large-documents 150`
- long-ids (consistency), seed 0: **refused-ValueError** UnsupportedSubject. subject id 'uuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuu'... (4,096 characters) cannot be sent to SpiceDB: object ids are 1 to 1024 letters, digits and /_\|-=+
  Replay: `python benchmarks/paper/conformance_campaign.py run --targets spicedb-tenant --seed-list 0 --variants long-ids --examples 10 --stress-examples 3 --large-documents 150`
- scalar-fields (consistency), seed 1: **refused-ValueError** UnsupportedSubject. subject id 'zoë' cannot be sent to SpiceDB: object ids are 1 to 1024 letters, digits and /_\|-=+
  Replay: `python benchmarks/paper/conformance_campaign.py run --targets spicedb-tenant --seed-list 1 --variants scalar-fields --examples 10 --stress-examples 3 --large-documents 150`

## cerbos

examples/cerbos/policies/document.yaml (metadata ACLs), loaded at startup as CI loads it.

Seeds 0-19; 10 corpora per seed for the default variant, 3 for the others; large corpora of up to 150 documents.

Image `ghcr.io/cerbos/cerbos:0.56.0`, id `sha256:9769be8555e0d7a5bf8da1d9b5bb6b64dfa7a8350a6a42d752e7dae7cbc6e584`, digests ['ghcr.io/cerbos/cerbos@sha256:540643bc67ba628011a150ad1d3370f285daa38995be5cd7a4be181da902bec1'].
Reported: `{"buildDate": "2026-09-30T06:22:34Z", "commit": "98604d71b79dafdc16ac57e4712fc435227e7c0f", "version": "0.56.0"}`.
Python packages: wardowl 2.1.0.

| Variant | Mode | Seeds | Pass | Violations | Refused | Errors | Subjects passing |
|---|---|---:|---:|---|---|---|---:|
| default | consistency | 20 | 20 | 0 | 0 | 0 | 240/240 |
| unicode-case | consistency | 20 | 20 | 0 | 0 | 0 | 160/160 |
| numeric-strings | consistency | 20 | 20 | 0 | 0 | 0 | 160/160 |
| many-groups | consistency | 20 | 20 | 0 | 0 | 0 | 60/60 |
| many-hits | consistency | 20 | 20 | 0 | 0 | 0 | 80/80 |
| long-ids | consistency | 20 | 20 | 0 | 0 | 0 | 160/160 |
| scalar-fields | consistency | 20 | 0 | 20 (filter-check-disagree 20) | 0 | 0 | 33/160 |

The first run of each kind of failure:

- scalar-fields (consistency), seed 0: **conformance-violation** filter-check-disagree. filter_for and check disagree (seed=0, example 0; rerun with the same seed to reproduce)
  Disagreeing hit: carol, doc-024 {"allowed_groups": "Eng", "doc_id": "doc-024"}: the filter allows, check denies; the reference allows, as the filter does
  Disagreeing hit: carol, doc-007 {"allowed_groups": "legal", "allowed_users": {"id": "zoë"}, "doc_id": "doc-007"}: the filter allows, check denies; the reference allows, as the filter does
  Disagreeing hit: bob, doc-024 {"allowed_groups": "Eng", "doc_id": "doc-024"}: the filter allows, check denies; the reference allows, as the filter does
  Replay: `python benchmarks/paper/conformance_campaign.py run --targets cerbos --seed-list 0 --variants scalar-fields --examples 10 --stress-examples 3 --large-documents 150`

## cerbos-tenant

acceptance/policies/cerbos/document.yaml (tenant equality and sharing), loaded at startup.

Seeds 0-19; 10 corpora per seed for the default variant, 3 for the others; large corpora of up to 150 documents.

Image `ghcr.io/cerbos/cerbos:0.56.0`, id `sha256:9769be8555e0d7a5bf8da1d9b5bb6b64dfa7a8350a6a42d752e7dae7cbc6e584`, digests ['ghcr.io/cerbos/cerbos@sha256:540643bc67ba628011a150ad1d3370f285daa38995be5cd7a4be181da902bec1'].
Reported: `{"buildDate": "2026-09-30T06:22:34Z", "commit": "98604d71b79dafdc16ac57e4712fc435227e7c0f", "version": "0.56.0"}`.
Python packages: wardowl 2.1.0.

| Variant | Mode | Seeds | Pass | Violations | Refused | Errors | Subjects passing |
|---|---|---:|---:|---|---|---|---:|
| default | consistency | 20 | 20 | 0 | 0 | 0 | 240/240 |
| unicode-case | consistency | 20 | 20 | 0 | 0 | 0 | 160/160 |
| numeric-strings | consistency | 20 | 20 | 0 | 0 | 0 | 160/160 |
| many-groups | consistency | 20 | 20 | 0 | 0 | 0 | 60/60 |
| many-hits | consistency | 20 | 20 | 0 | 0 | 0 | 80/80 |
| long-ids | consistency | 20 | 20 | 0 | 0 | 0 | 160/160 |
| scalar-fields | consistency | 20 | 1 | 19 (filter-check-disagree 19) | 0 | 0 | 119/160 |

The first run of each kind of failure:

- scalar-fields (consistency), seed 0: **conformance-violation** filter-check-disagree. filter_for and check disagree (seed=0, example 0; rerun with the same seed to reproduce)
  Disagreeing hit: alice, doc-006 {"allowed_users": ["alice"], "doc_id": "doc-006", "tenant": ["northwind"]}: the filter allows, check denies; the reference allows, as the filter does
  Disagreeing hit: carol, doc-007 {"allowed_groups": "legal", "allowed_users": {"id": "zoë"}, "doc_id": "doc-007", "tenant": "acme"}: the filter allows, check denies; the reference allows, as the filter does
  Disagreeing hit: bob, doc-024 {"allowed_groups": "Eng", "doc_id": "doc-024", "tenant": "globex"}: the filter allows, check denies; the reference allows, as the filter does
  Replay: `python benchmarks/paper/conformance_campaign.py run --targets cerbos-tenant --seed-list 0 --variants scalar-fields --examples 10 --stress-examples 3 --large-documents 150`

## keto

acceptance/policies/keto (Document#view of users and Group#members), tuples replaced for every run, groups checked as subject sets (group_subjects=True), Keto's default batch limit of 10.

Seeds 0-19; 10 corpora per seed for the default variant, 3 for the others; large corpora of up to 150 documents.

Image `oryd/keto:v26.2.0`, id `sha256:0c325feb33d9de6016aa3e628c7bcfa5415f09ab808bbc2db42e58af286bca22`, digests ['oryd/keto@sha256:bfdb8b9e283aedbd9e1d005c44eb1bbefd2096b2cb5b5aa0b7360b6e39c178d2'].
Reported: `{"keto": "v26.2.0"}`.
Python packages: wardowl 2.1.0.

| Variant | Mode | Seeds | Pass | Violations | Refused | Errors | Subjects passing |
|---|---|---:|---:|---|---|---|---:|
| default | consistency | 20 | 20 | 0 | 0 | 0 | 240/240 |
| unicode-case | consistency | 20 | 20 | 0 | 0 | 0 | 160/160 |
| numeric-strings | consistency | 20 | 20 | 0 | 0 | 0 | 160/160 |
| many-groups | consistency | 20 | 20 | 0 | 0 | 0 | 60/60 |
| many-hits | consistency | 20 | 20 | 0 | 0 | 0 | 80/80 |
| long-ids | consistency | 20 | 20 | 0 | 0 | 0 | 160/160 |
| scalar-fields | consistency | 20 | 20 | 0 | 0 | 0 | 160/160 |

## cedar

the metadata ACL policy of wardowl's tests, in process.

Seeds 0-19; 10 corpora per seed for the default variant, 3 for the others; large corpora of up to 150 documents.

Python packages: wardowl 2.1.0, cedarpy 4.12.2.

| Variant | Mode | Seeds | Pass | Violations | Refused | Errors | Subjects passing |
|---|---|---:|---:|---|---|---|---:|
| default | consistency | 20 | 20 | 0 | 0 | 0 | 240/240 |
| unicode-case | consistency | 20 | 20 | 0 | 0 | 0 | 160/160 |
| numeric-strings | consistency | 20 | 20 | 0 | 0 | 0 | 160/160 |
| many-groups | consistency | 20 | 20 | 0 | 0 | 0 | 60/60 |
| many-hits | consistency | 20 | 20 | 0 | 0 | 0 | 80/80 |
| long-ids | consistency | 20 | 20 | 0 | 0 | 0 | 160/160 |
| scalar-fields | consistency | 20 | 20 | 0 | 0 | 0 | 160/160 |

## cedar-tenant

acceptance/policies/cedar/documents.cedar (sharing, and a forbid across tenants), in process.

Seeds 0-19; 10 corpora per seed for the default variant, 3 for the others; large corpora of up to 150 documents.

Python packages: wardowl 2.1.0, cedarpy 4.12.2.

| Variant | Mode | Seeds | Pass | Violations | Refused | Errors | Subjects passing |
|---|---|---:|---:|---|---|---|---:|
| default | consistency | 20 | 20 | 0 | 0 | 0 | 240/240 |
| unicode-case | consistency | 20 | 20 | 0 | 0 | 0 | 160/160 |
| numeric-strings | consistency | 20 | 20 | 0 | 0 | 0 | 160/160 |
| many-groups | consistency | 20 | 20 | 0 | 0 | 0 | 60/60 |
| many-hits | consistency | 20 | 20 | 0 | 0 | 0 | 80/80 |
| long-ids | consistency | 20 | 20 | 0 | 0 | 0 | 160/160 |
| scalar-fields | consistency | 20 | 20 | 0 | 0 | 0 | 160/160 |

## casbin

the RBAC model of wardowl's tests with '*' for everyone, a policy row per grant, groups from the subject (group_subjects=True), in process.

Seeds 0-19; 10 corpora per seed for the default variant, 3 for the others; large corpora of up to 150 documents.

Python packages: wardowl 2.1.0, casbin 1.43.0.

| Variant | Mode | Seeds | Pass | Violations | Refused | Errors | Subjects passing |
|---|---|---:|---:|---|---|---|---:|
| default | consistency | 20 | 20 | 0 | 0 | 0 | 240/240 |
| unicode-case | consistency | 20 | 20 | 0 | 0 | 0 | 160/160 |
| numeric-strings | consistency | 20 | 20 | 0 | 0 | 0 | 160/160 |
| many-groups | consistency | 20 | 20 | 0 | 0 | 0 | 60/60 |
| many-hits | consistency | 20 | 20 | 0 | 0 | 0 | 80/80 |
| long-ids | consistency | 20 | 20 | 0 | 0 | 0 | 160/160 |
| scalar-fields | consistency | 20 | 20 | 0 | 0 | 0 | 160/160 |

## casbin-tenant

acceptance/policies/casbin/model.conf (RBAC with a domain per tenant), a policy row per grant and a grouping row per membership, in process.

Seeds 0-19; 10 corpora per seed for the default variant, 3 for the others; large corpora of up to 150 documents.

Python packages: wardowl 2.1.0, casbin 1.43.0.

| Variant | Mode | Seeds | Pass | Violations | Refused | Errors | Subjects passing |
|---|---|---:|---:|---|---|---|---:|
| default | consistency | 20 | 20 | 0 | 0 | 0 | 240/240 |
| unicode-case | consistency | 20 | 20 | 0 | 0 | 0 | 160/160 |
| numeric-strings | consistency | 20 | 20 | 0 | 0 | 0 | 160/160 |
| many-groups | consistency | 20 | 20 | 0 | 0 | 0 | 60/60 |
| many-hits | consistency | 20 | 20 | 0 | 0 | 0 | 80/80 |
| long-ids | consistency | 20 | 20 | 0 | 0 | 0 | 160/160 |
| scalar-fields | consistency | 20 | 20 | 0 | 0 | 0 | 160/160 |

